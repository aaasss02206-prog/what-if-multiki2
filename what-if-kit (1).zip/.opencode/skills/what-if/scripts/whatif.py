#!/usr/bin/env python3
"""what-if cartoon pipeline.

Run from the cartoons folder (the one that contains .opencode and .env):

    python .opencode/skills/what-if/scripts/whatif.py <command> [slug] [options]

Commands
    setup                 check tools, install the Remotion studio (first run only)
    status                ElevenLabs credits left this month
    new <slug>            create episodes/<slug>/ with a fact.md template
    check <slug>          lint episode.json (framing, pace, story, variety)
    board <slug>          render one frame per shot + board.png contact sheet
    frame <slug> <n>      render shot n as a full-size PNG
    voice <slug>          narration with word timings (cached, --mock = no credits)
    sfx <slug>            sound effects (cached in ./sfx, --mock = synthesised)
    mix <slug>            voice + sfx (+ music) at the right loudness
    render <slug>         final video (--draft = half size, fast)
    build <slug>          voice + sfx + mix + render in one go
    sheet                 character-sheet.png with every character
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

SKILL = Path(__file__).resolve().parent.parent
ENGINE = SKILL / "engine"
ROOT = Path.cwd()
STUDIO = ROOT / "studio"
EPISODES = ROOT / "episodes"
SFX_DIR = ROOT / "sfx"
MUSIC_DIR = ROOT / "music"
CHARACTERS = ROOT / "characters.json"
FPS = 30
TAIL = 0.7
CPS = 14.5
API = "https://api.elevenlabs.io/v1"
FALLBACK_VOICE = "nPczCjzI2devNBz1zQrb"  # "Brian", a default voice every account has


def say(msg: str = "") -> None:
    print(msg, flush=True)


def die(msg: str, code: int = 1) -> None:
    say(f"\nFAILED: {msg}")
    sys.exit(code)


def exe(name: str) -> str | None:
    return shutil.which(name)


def run(cmd: list[str], cwd: Path | None = None, quiet: bool = False, check: bool = True) -> subprocess.CompletedProcess:
    p = subprocess.run(cmd, cwd=str(cwd) if cwd else None, text=True, encoding="utf-8", errors="replace",
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if not quiet and p.stdout.strip():
        say(p.stdout.strip())
    if check and p.returncode != 0:
        if quiet and p.stdout.strip():
            say(p.stdout.strip()[-3000:])
        die(f"command failed ({p.returncode}): {' '.join(str(c) for c in cmd[:4])} ...")
    return p


def load_env() -> dict[str, str]:
    env = dict(os.environ)
    f = ROOT / ".env"
    if f.exists():
        for line in f.read_text(encoding="utf-8-sig").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            v = v.strip().strip('"').strip("'")
            if v:
                env[k.strip()] = v
    return env


ENV = load_env()


def api_key(required: bool = True) -> str | None:
    key = ENV.get("ELEVENLABS_API_KEY", "").strip()
    if not key or key.lower().startswith(("your", "paste", "sk_xxx", "вставь")):
        if required:
            die("no ElevenLabs key. Create a file named .env in this folder with one line:\n"
                "        ELEVENLABS_API_KEY=your_key\n"
                "    (key: elevenlabs.io -> Developers -> API Keys). To try everything without a key add --mock.")
        return None
    return key


def need_requests():
    try:
        import requests  # noqa: F401
        return requests
    except ImportError:
        die("Python package 'requests' is missing. Run:  python -m pip install requests pillow")


# ----------------------------------------------------------------------------
# episode loading
# ----------------------------------------------------------------------------

def ep_dir(slug: str) -> Path:
    d = EPISODES / slug
    if not d.exists():
        have = sorted(p.name for p in EPISODES.glob("*") if p.is_dir()) if EPISODES.exists() else []
        die(f"episodes/{slug} does not exist. Existing episodes: {', '.join(have) or 'none'}")
    return d


def load_episode(slug: str) -> dict:
    d = ep_dir(slug)
    f = d / "episode.json"
    if not f.exists():
        die(f"episodes/{slug}/episode.json does not exist yet - write it first (see references/episode-format.md)")
    try:
        ep = json.loads(f.read_text(encoding="utf-8-sig"))
    except json.JSONDecodeError as e:
        die(f"episodes/{slug}/episode.json is not valid JSON: line {e.lineno}, column {e.colno}: {e.msg}\n"
            "    Typical causes: a trailing comma, a missing comma between shots, a comment, single quotes.")
    # long episodes may keep their shots in parts: shots-01-hook.json, shots-02-small.json ...
    parts = sorted(d.glob("shots-*.json"))
    if parts:
        shots = list(ep.get("shots") or [])
        for p in parts:
            try:
                chunk = json.loads(p.read_text(encoding="utf-8-sig"))
            except json.JSONDecodeError as e:
                die(f"{p.name} is not valid JSON: line {e.lineno}, column {e.colno}: {e.msg}")
            shots.extend(chunk if isinstance(chunk, list) else chunk.get("shots", []))
        ep["shots"] = shots
    ep.setdefault("slug", slug)
    if ep["slug"] != slug:
        die(f'"slug" inside episode.json is "{ep["slug"]}" but the folder is "{slug}" - make them equal')
    return ep


def narration(ep: dict) -> tuple[str, list[int]]:
    text, starts = "", []
    for s in ep["shots"]:
        piece = re.sub(r"\s+", " ", str(s.get("say", ""))).strip()
        if text:
            text += " "
        starts.append(len(text))
        text += piece
    return text, starts


def voice_id_cfg() -> tuple[str, str]:
    return ENV.get("ELEVENLABS_VOICE", "Brian").strip(), ENV.get("ELEVENLABS_MODEL", "eleven_multilingual_v2").strip()


def narration_hash(ep: dict) -> str:
    text, _ = narration(ep)
    pauses = [s.get("pause", 0) for s in ep["shots"]]
    return hashlib.sha1(json.dumps([text, pauses], ensure_ascii=False).encode()).hexdigest()[:16]


def load_characters() -> dict:
    base = json.loads((ENGINE / "src" / "characters.default.json").read_text(encoding="utf-8"))
    if CHARACTERS.exists():
        try:
            base.update(json.loads(CHARACTERS.read_text(encoding="utf-8-sig")))
        except json.JSONDecodeError as e:
            die(f"characters.json is not valid JSON: line {e.lineno}, column {e.colno}: {e.msg}")
    return base


def load_timing(slug: str, ep: dict, strict: bool = False) -> dict | None:
    f = ep_dir(slug) / "timing.json"
    if not f.exists():
        if strict:
            die("no voice yet - run the voice command first")
        return None
    t = json.loads(f.read_text(encoding="utf-8"))
    if t.get("hash") != narration_hash(ep) or len(t.get("shots", [])) != len(ep["shots"]):
        if strict:
            die("the narration changed after the voice was generated - run the voice command again")
        say("note: narration changed since the last voice run - timings are estimated until you run voice again")
        return None
    return t


def write_props(slug: str, strict_timing: bool = False) -> tuple[Path, dict, dict | None]:
    ep = load_episode(slug)
    timing = load_timing(slug, ep, strict_timing)
    props = {"episode": ep, "timing": timing, "characters": load_characters()}
    d = STUDIO / ".props"
    d.mkdir(parents=True, exist_ok=True)
    f = d / f"{slug}.json"
    f.write_text(json.dumps(props, ensure_ascii=False), encoding="utf-8")
    return f, ep, timing


# ----------------------------------------------------------------------------
# setup
# ----------------------------------------------------------------------------

def engine_stamp() -> str:
    h = hashlib.sha1()
    for p in sorted(ENGINE.rglob("*")):
        if p.is_file() and "node_modules" not in p.parts:
            h.update(p.relative_to(ENGINE).as_posix().encode())
            h.update(p.read_bytes())
    return h.hexdigest()[:16]


def studio_ready() -> bool:
    return (STUDIO / "node_modules" / "remotion").exists() and (STUDIO / ".stamp").exists() \
        and (STUDIO / ".stamp").read_text().strip() == engine_stamp()


def ensure_studio() -> None:
    if not studio_ready():
        cmd_setup([])


def cmd_setup(_: list[str]) -> None:
    say("== what-if setup ==")
    ok = True
    node, npm, npx, ff, fp = exe("node"), exe("npm"), exe("npx"), exe("ffmpeg"), exe("ffprobe")
    if node:
        v = run([node, "-v"], quiet=True).stdout.strip()
        major = int(re.sub(r"\D", "", v.split(".")[0]) or 0)
        say(f"[ok]   Node.js {v}" if major >= 18 else f"[FAIL] Node.js {v} is too old - need 18 or newer")
        ok &= major >= 18
    else:
        say("[FAIL] Node.js not found   (Windows: winget install OpenJS.NodeJS.LTS)")
        ok = False
    if not (npm and npx):
        say("[FAIL] npm / npx not found - they come with Node.js; close and reopen the terminal")
        ok = False
    if ff and fp:
        say("[ok]   ffmpeg " + run([ff, "-version"], quiet=True).stdout.split("\n")[0].split(" ")[2])
    else:
        say("[FAIL] ffmpeg not found    (Windows: winget install Gyan.FFmpeg, then reopen the terminal)")
        ok = False
    say(f"[ok]   Python {sys.version.split()[0]}")
    miss = []
    for mod, pkg in (("requests", "requests"), ("PIL", "pillow")):
        try:
            __import__(mod)
        except ImportError:
            miss.append(pkg)
    if miss:
        say(f"[FAIL] Python packages missing: {' '.join(miss)}   (run: python -m pip install requests pillow)")
        ok = False
    else:
        say("[ok]   Python packages: requests, pillow")
    if not ok:
        die("install the missing tools above, close and reopen the terminal, start opencode again and re-run setup")

    for d in (EPISODES, SFX_DIR, MUSIC_DIR):
        d.mkdir(exist_ok=True)
    if not CHARACTERS.exists():
        shutil.copy(ENGINE / "src" / "characters.default.json", CHARACTERS)
        say("[ok]   characters.json created (the cast lives here - edit it to add your own heroes)")
    else:
        say("[ok]   characters.json")

    if studio_ready():
        say("[ok]   studio (Remotion) is installed")
    else:
        say("[..]   installing the studio (Remotion). First time only, 1-4 minutes ...")
        STUDIO.mkdir(exist_ok=True)
        for p in ENGINE.iterdir():
            if p.name == "node_modules":
                continue
            dst = STUDIO / p.name
            if p.is_dir():
                shutil.copytree(p, dst, dirs_exist_ok=True)
            else:
                shutil.copy(p, dst)
        run([npm, "install", "--no-audit", "--no-fund", "--loglevel=error"], cwd=STUDIO, quiet=True)
        (STUDIO / ".stamp").write_text(engine_stamp())
        say("[ok]   studio installed")

    if api_key(required=False):
        say("[ok]   ElevenLabs key found in .env")
        try:
            cmd_status([])
        except SystemExit:
            pass
    else:
        say("[--]   no ElevenLabs key in .env yet: voice and sfx will only work with --mock\n"
            "       add a line  ELEVENLABS_API_KEY=your_key  to the file .env in this folder")
    say("\nSETUP OK")


def cmd_status(_: list[str]) -> None:
    requests = need_requests()
    key = api_key()
    try:
        r = requests.get(f"{API}/user/subscription", headers={"xi-api-key": key}, timeout=30)
    except Exception as e:  # network
        die(f"cannot reach ElevenLabs: {e}")
    if r.status_code == 401:
        say("[--]   ElevenLabs: the key is rejected (401), or it has no 'User: read' permission. "
            "If voice also fails, create a new key with all permissions.")
        return
    if r.status_code != 200:
        say(f"[--]   ElevenLabs status {r.status_code}: {r.text[:200]}")
        return
    j = r.json()
    used, limit = j.get("character_count", 0), j.get("character_limit", 0)
    say(f"[ok]   ElevenLabs plan: {j.get('tier', '?')} - credits left: {limit - used} of {limit}")
    if j.get("tier") == "free":
        say("       free plan = non-commercial use + credit 'elevenlabs.io' in the video description;\n"
            "       a monetised channel needs a paid plan (Starter or higher).")


# ----------------------------------------------------------------------------
# new / check / board / frame / sheet
# ----------------------------------------------------------------------------

FACT_TEMPLATE = """# Fact check - {slug}

## Claim (one sentence, as it will be said in the episode)


## Source
- Title:
- Publisher / journal, year:
- URL:

## Exact quote from the source that supports the claim


## What the source does NOT say (so we do not overclaim)


## Status
NOT VERIFIED BY A HUMAN YET - open the URL and read it before publishing.
"""


def cmd_new(a: list[str]) -> None:
    if not a:
        die("usage: new <slug>")
    slug = a[0]
    if not re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", slug):
        die('slug must be lowercase-kebab-case, e.g. "see-one-minute-ahead"')
    d = EPISODES / slug
    d.mkdir(parents=True, exist_ok=True)
    f = d / "fact.md"
    if not f.exists():
        f.write_text(FACT_TEMPLATE.format(slug=slug), encoding="utf-8")
    say(f"episodes/{slug}/ is ready. Next: fill fact.md, then write episodes/{slug}/episode.json")


def remotion(args: list[str], quiet: bool = True) -> None:
    ensure_studio()
    cmd = [exe("npx") or "npx", "remotion", *args, "--log=error"]
    browser = ENV.get("WHATIF_BROWSER", "").strip()
    if browser:
        cmd += [f"--browser-executable={browser}", "--chrome-mode=chrome-for-testing"]
    run(cmd, cwd=STUDIO, quiet=quiet)


def lint(slug: str, strict_timing: bool = False) -> tuple[int, dict]:
    ensure_studio()
    props, ep, _ = write_props(slug, strict_timing)
    out = ep_dir(slug) / "lint.json"
    p = run([exe("npx") or "npx", "tsx", "tools/lint.ts", str(props), "--json", str(out)], cwd=STUDIO, check=False)
    rc = p.returncode
    if rc not in (0, 1):
        die("the checker itself crashed (see the output above)")
    extra = 0
    f = ep_dir(slug) / "fact.md"
    txt = f.read_text(encoding="utf-8") if f.exists() else ""
    if not re.search(r"https?://\S+\.\S+", txt):
        say("ERROR episode [FACT_FILE] fact.md has no source URL\n        fix: write the claim, the source and its URL into fact.md (never invent a URL)")
        extra += 1
    text, _ = narration(ep)
    model = voice_id_cfg()[1]
    cost = len(text) // 2 if ("flash" in model or "turbo" in model) else len(text)
    say(f"voice cost for this narration: about {cost} ElevenLabs credits ({len(text)} characters, model {model})")
    data = json.loads(out.read_text(encoding="utf-8")) if out.exists() else {"issues": []}
    return (1 if (rc or extra) else 0), data


def cmd_check(a: list[str]) -> None:
    if not a:
        die("usage: check <slug>")
    rc, _ = lint(a[0])
    sys.exit(rc)


def cmd_board(a: list[str]) -> None:
    if not a:
        die("usage: board <slug>")
    slug = a[0]
    rc, data = lint(slug)
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        die("Python package 'pillow' is missing. Run:  python -m pip install requests pillow")
    props, ep, _ = write_props(slug)
    d = ep_dir(slug)
    frames = d / "board"
    if frames.exists():
        shutil.rmtree(frames)
    say("rendering one frame per shot ...")
    remotion(["render", "src/index.ts", "Board", str(frames), f"--props={props}", "--sequence",
              "--image-format=jpeg", "--scale=0.34"])
    files = sorted(list(frames.glob("*.jpeg")) + list(frames.glob("*.jpg")),
                   key=lambda p: int(re.sub(r"\D", "", p.stem) or 0))
    shots = ep["shots"]
    if len(files) != len(shots):
        die(f"expected {len(shots)} frames, got {len(files)}")
    bad: dict[int, list[str]] = {}
    for i in data.get("issues", []):
        if i.get("level") == "error" and i.get("shot"):
            bad.setdefault(i["shot"], []).append(i["code"])

    def font(size: int):
        for name in ("arialbd.ttf", "Arial Bold.ttf", "DejaVuSans-Bold.ttf", "Arial.ttf", "arial.ttf"):
            try:
                return ImageFont.truetype(name, size)
            except Exception:
                continue
        return ImageFont.load_default()

    cols = 5 if len(shots) <= 40 else 8
    first = Image.open(files[0])
    cw, ch = first.size
    cap, pad = 64, 14
    rows = (len(shots) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * (cw + pad) + pad, rows * (ch + cap + pad) + pad + 56), "#15161f")
    dr = ImageDraw.Draw(sheet)
    f_big, f_small = font(26), font(17)
    n_bad = len(bad)
    dr.text((pad, 14), f"{ep.get('title', slug)}  -  {len(shots)} shots  -  " +
            (f"{n_bad} shot(s) with errors (red)" if n_bad else "all shots pass the check"),
            fill="#ffffff", font=f_big)
    for i, fpath in enumerate(files):
        no = i + 1
        x = pad + (i % cols) * (cw + pad)
        y = 56 + pad + (i // cols) * (ch + cap + pad)
        sheet.paste(Image.open(fpath), (x, y))
        red = no in bad
        dr.rectangle([x - 4, y - 4, x + cw + 3, y + ch + 3], outline="#ff2d2d" if red else "#3a3d52", width=6 if red else 2)
        dr.rectangle([x, y, x + 58, y + 34], fill="#ff2d2d" if red else "#15161f")
        dr.text((x + 8, y + 3), f"{no:02d}", fill="#ffffff", font=f_big)
        line = (" ".join(bad[no]) if red else f"[{shots[i].get('beat', '?')}] {shots[i].get('say', '')}")
        line = line.encode("ascii", "replace").decode() if not red else line
        while dr.textlength(line, font=f_small) > cw * 2 - 20 and len(line) > 8:
            line = line[:-4] + "..."
        half = len(line)
        while dr.textlength(line[:half], font=f_small) > cw - 6 and half > 4:
            half -= 1
        if half < len(line) and " " in line[:half]:
            half = line[:half].rindex(" ")
        dr.text((x, y + ch + 8), line[:half], fill="#ff8080" if red else "#c9cce0", font=f_small)
        dr.text((x, y + ch + 30), line[half:].strip(), fill="#ff8080" if red else "#c9cce0", font=f_small)
        Image.open(fpath).close()
    out = d / "board.png"
    sheet.save(out)
    say(f"storyboard saved: episodes/{slug}/board.png  ({len(shots)} frames, {n_bad} marked red)")
    say("frames one by one: episodes/%s/board/" % slug)
    if rc:
        say("\nRESULT: the storyboard has errors. Fix episode.json and run board again.")
    sys.exit(rc)


def cmd_frame(a: list[str]) -> None:
    if len(a) < 2 or not a[1].isdigit():
        die("usage: frame <slug> <shot number>")
    slug, no = a[0], int(a[1])
    props, ep, _ = write_props(slug)
    if not 1 <= no <= len(ep["shots"]):
        die(f"shot {no} does not exist (the episode has {len(ep['shots'])} shots)")
    out = ep_dir(slug) / "frames" / f"shot-{no:02d}.png"
    out.parent.mkdir(exist_ok=True)
    remotion(["still", "src/index.ts", "Board", str(out), f"--props={props}", f"--frame={no - 1}"])
    say(f"saved: episodes/{slug}/frames/shot-{no:02d}.png  (1920x1080 - also usable as a thumbnail base)")


def cmd_sheet(_: list[str]) -> None:
    ensure_studio()
    d = STUDIO / ".props"
    d.mkdir(exist_ok=True)
    f = d / "_sheet.json"
    chars = load_characters()
    f.write_text(json.dumps({"episode": {"slug": "sheet", "title": "", "hero": "max", "shots": [{"say": "x"}]},
                             "timing": None, "characters": chars}), encoding="utf-8")
    out = ROOT / "character-sheet.png"
    remotion(["still", "src/index.ts", "Sheet", str(out), f"--props={f}"])
    say(f"saved: character-sheet.png  ({len(chars)} characters: {', '.join(chars)})")


# ----------------------------------------------------------------------------
# voice
# ----------------------------------------------------------------------------

def ffmpeg(args: list[str], quiet: bool = True) -> subprocess.CompletedProcess:
    ff = exe("ffmpeg") or die("ffmpeg not found - run setup")
    return run([ff, "-hide_banner", "-y", *args], quiet=quiet)


def media_duration(path: Path) -> float:
    fp = exe("ffprobe") or die("ffprobe not found - run setup")
    p = run([fp, "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(path)], quiet=True)
    return float(p.stdout.strip().splitlines()[-1])


def resolve_voice(requests, key: str, want: str) -> tuple[str, str]:
    try:
        r = requests.get(f"{API}/voices", headers={"xi-api-key": key}, timeout=30)
        voices = r.json().get("voices", []) if r.status_code == 200 else []
    except Exception:
        voices = []
    low = want.lower()
    for v in voices:
        if v.get("voice_id") == want:
            return v["voice_id"], v.get("name", want)
    for v in voices:
        if v.get("name", "").lower().split(" - ")[0].strip() == low or v.get("name", "").lower().startswith(low):
            return v["voice_id"], v["name"]
    if re.fullmatch(r"[A-Za-z0-9]{20}", want):
        return want, want
    pre = [v for v in voices if v.get("category") == "premade"]
    if pre:
        say(f'note: voice "{want}" not found in your account - using "{pre[0]["name"]}". '
            f"Available: {', '.join(v['name'].split(' - ')[0] for v in pre[:12])}")
        return pre[0]["voice_id"], pre[0]["name"]
    return FALLBACK_VOICE, "Brian"


def tts(requests, key: str, voice: str, model: str, text: str, prev: str, nxt: str) -> dict:
    body = {"text": text, "model_id": model,
            "voice_settings": {"stability": 0.5, "similarity_boost": 0.75, "style": 0.0, "use_speaker_boost": True}}
    speed = ENV.get("ELEVENLABS_SPEED", "").strip()
    if speed:
        body["voice_settings"]["speed"] = float(speed)
    if prev:
        body["previous_text"] = prev[-300:]
    if nxt:
        body["next_text"] = nxt[:300]
    r = requests.post(f"{API}/text-to-speech/{voice}/with-timestamps", params={"output_format": "mp3_44100_128"},
                      headers={"xi-api-key": key, "Content-Type": "application/json"}, json=body, timeout=300)
    if r.status_code != 200:
        try:
            detail = r.json().get("detail", {})
            status = detail.get("status", "") if isinstance(detail, dict) else ""
            message = detail.get("message", "") if isinstance(detail, dict) else str(detail)
        except Exception:
            status, message = "", r.text[:300]
        raise RuntimeError(f"{r.status_code}|{status}|{message}")
    return r.json()


def cmd_voice(a: list[str]) -> None:
    if not a:
        die("usage: voice <slug> [--mock] [--force]")
    slug, mock, force = a[0], "--mock" in a, "--force" in a
    ep = load_episode(slug)
    d = ep_dir(slug)
    text, starts = narration(ep)
    shots = ep["shots"]
    h = narration_hash(ep)
    tfile, afile = d / "timing.json", d / "voice.mp3"
    if tfile.exists() and afile.exists() and not force:
        old = json.loads(tfile.read_text(encoding="utf-8"))
        if old.get("hash") == h and old.get("mock", False) == mock:
            say(f"voice is up to date ({old.get('duration', 0):.1f}s) - nothing to generate, no credits spent")
            return
        if old.get("hash") == h and not old.get("mock") and mock:
            say("a real voice already exists for this narration - keeping it")
            return

    char_start: list[float] = []
    char_end: list[float] = []
    if mock:
        for i, _c in enumerate(text):
            char_start.append(i / CPS)
            char_end.append((i + 1) / CPS)
        total = len(text) / CPS
        ffmpeg(["-f", "lavfi", "-i", "anullsrc=r=44100:cl=mono", "-t", f"{total:.3f}", "-q:a", "9", str(afile)])
        say(f"MOCK voice: silent track, {total:.1f}s, timings estimated at {CPS} characters per second")
        voice_name = "mock"
    else:
        requests = need_requests()
        key = api_key()
        want, model = voice_id_cfg()
        voice, voice_name = resolve_voice(requests, key, want)
        # chunk on shot boundaries so one request never gets too long
        chunks: list[tuple[int, int]] = []
        c0 = 0
        for i in range(1, len(shots) + 1):
            end = starts[i] if i < len(shots) else len(text)
            nxt_end = starts[i + 1] if i + 1 < len(shots) else len(text)
            if i == len(shots) or nxt_end - c0 > 2800:
                chunks.append((c0, end))
                c0 = end
        chunks = [c for c in chunks if c[1] > c[0]]
        parts: list[Path] = []
        offset = 0.0
        say(f'voice "{voice_name}", model {model}, {len(text)} characters, {len(chunks)} request(s) ...')
        for n, (s0, s1) in enumerate(chunks):
            piece = text[s0:s1]
            try:
                j = tts(requests, key, voice, model, piece, text[:s0], text[s1:])
            except RuntimeError as e:
                code, status, message = (str(e).split("|", 2) + ["", ""])[:3]
                hint = {
                    "401": "the API key is wrong or has no text-to-speech permission - create a new key with full access and put it in .env",
                    "quota_exceeded": "not enough ElevenLabs credits left this month. Options: wait for the monthly reset, shorten the "
                                      "narration, set ELEVENLABS_MODEL=eleven_flash_v2_5 in .env (half price), or upgrade the plan",
                }.get(status or code, "")
                low = message.lower()
                if "free" in low and ("library" in low or "voice" in low):
                    hint = ("this voice is from the Voice Library, which the free plan cannot use through the API. "
                            "Set ELEVENLABS_VOICE to a default voice (Brian, George, Sarah, Daniel ...) or upgrade the plan")
                if "model" in low and ("not" in low or "deprecat" in low):
                    hint = "this model id is not available - set ELEVENLABS_MODEL in .env to a current one (see elevenlabs.io/docs/models)"
                die(f"ElevenLabs said {code} {status}: {message}\n    {hint}")
            al = j.get("alignment") or j.get("normalized_alignment")
            part = d / f".voice-{n:02d}.mp3"
            part.write_bytes(base64.b64decode(j["audio_base64"]))
            dur = media_duration(part)
            if not al or not al.get("character_start_times_seconds"):
                st = [dur * i / max(1, len(piece)) for i in range(len(piece))]
                en = [dur * (i + 1) / max(1, len(piece)) for i in range(len(piece))]
            elif len(al["characters"]) != len(piece):
                # fall back to proportional mapping if the alignment length differs
                st, en = al["character_start_times_seconds"], al["character_end_times_seconds"]
                k = len(st) / max(1, len(piece))
                st = [st[min(len(st) - 1, int(i * k))] for i in range(len(piece))]
                en = [en[min(len(en) - 1, int(i * k))] for i in range(len(piece))]
            else:
                st, en = al["character_start_times_seconds"], al["character_end_times_seconds"]
            char_start += [offset + x for x in st]
            char_end += [offset + x for x in en]
            offset += dur
            parts.append(part)
        if len(parts) == 1:
            shutil.move(str(parts[0]), afile)
        else:
            lst = d / ".voice-list.txt"
            lst.write_text("".join(f"file '{p.name}'\n" for p in parts), encoding="utf-8")
            ffmpeg(["-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(afile)])
            for p in parts + [lst]:
                p.unlink(missing_ok=True)

    # shot boundaries: cut a hair before the first word of the next shot
    total = media_duration(afile)
    cut = [0.0]
    for i in range(1, len(shots)):
        s0 = starts[i]
        while s0 < len(text) - 1 and text[s0] == " ":
            s0 += 1
        t_next = char_start[min(s0, len(char_start) - 1)]
        t_prev = char_end[max(0, starts[i] - 2)]
        cut.append(max(t_prev, t_next - 0.07, cut[-1] + 0.2))
    cut.append(max(total, cut[-1] + 0.2))

    words = []
    for m in re.finditer(r"\S+", text):
        words.append({"w": m.group(0), "start": round(char_start[m.start()], 3), "end": round(char_end[m.end() - 1], 3)})

    # optional pauses: splice silence into the audio after a shot
    pauses = [float(s.get("pause", 0) or 0) for s in shots]
    if any(p > 0 for p in pauses):
        seg, filt, n = [], [], 0
        shift, new_cut, start_seg = 0.0, [0.0], 0.0
        shifts = []
        for i, p in enumerate(pauses):
            shifts.append(shift)
            end = cut[i + 1]
            if p > 0 or i == len(pauses) - 1:
                filt.append(f"[0:a]atrim={start_seg:.3f}:{end:.3f},asetpts=PTS-STARTPTS,afade=t=out:st={max(0, end - start_seg - 0.02):.3f}:d=0.02[a{n}]")
                seg.append(f"[a{n}]")
                n += 1
                if p > 0:
                    filt.append(f"anullsrc=r=44100:cl=mono,atrim=0:{p:.3f}[a{n}]")
                    seg.append(f"[a{n}]")
                    n += 1
                start_seg = end
            shift += p
            new_cut.append(end + shift)
        filt.append(f"{''.join(seg)}concat=n={n}:v=0:a=1[out]")
        tmp = d / ".voice-paused.mp3"
        ffmpeg(["-i", str(afile), "-filter_complex", ";".join(filt), "-map", "[out]", "-q:a", "2", str(tmp)])
        shutil.move(str(tmp), afile)
        k = 0
        for w in words:
            while k + 1 < len(cut) - 1 and w["start"] >= cut[k + 1] - 0.001:
                k += 1
            w["start"] = round(w["start"] + shifts[k], 3)
            w["end"] = round(w["end"] + shifts[k], 3)
        cut = new_cut
        total = media_duration(afile)

    timing = {
        "hash": h, "mock": mock, "voice": voice_name, "duration": round(total, 3),
        "shots": [{"start": round(cut[i], 3), "end": round(cut[i + 1], 3)} for i in range(len(shots))],
        "words": words,
    }
    tfile.write_text(json.dumps(timing, ensure_ascii=False, indent=1), encoding="utf-8")
    longest = max(range(len(shots)), key=lambda i: cut[i + 1] - cut[i])
    say(f"voice saved: episodes/{slug}/voice.mp3  {total:.1f}s, {len(shots)} shots, "
        f"{len(shots) / total * 60:.0f} cuts per minute, longest shot {longest + 1} = {cut[longest + 1] - cut[longest]:.1f}s")
    if not mock:
        say(f"credits used for this voice: about {len(text) // 2 if ('flash' in voice_id_cfg()[1] or 'turbo' in voice_id_cfg()[1]) else len(text)}")
    say("next: run check again - now the pace is measured on the real voice")


# ----------------------------------------------------------------------------
# sound effects
# ----------------------------------------------------------------------------

# name: (prompt for ElevenLabs, seconds, synth recipe used for --mock / fallback)
SFX = {
    "whoosh": ("fast cartoon whoosh, air swish, short", 0.6, ("noise", 500, 6000, 0.45)),
    "pop": ("single cartoon pop, bubble pop, dry", 0.5, ("sweep", 420, 900, 0.09)),
    "ding": ("bright bell ding, single notification chime", 1.0, ("tone", 1568, 0, 0.9)),
    "boing": ("cartoon spring boing, comedic", 0.8, ("sweep", 180, 520, 0.45)),
    "thud": ("soft heavy thud, body falls on floor, cartoon", 0.6, ("tone", 70, 0, 0.3)),
    "rise": ("rising tension riser, short synth swell", 1.5, ("sweep", 200, 1400, 1.3)),
    "drop": ("deep bass drop impact, cinematic hit", 1.2, ("sweep", 220, 40, 0.9)),
    "cash": ("cash register ka-ching, coins", 1.0, ("tone", 2093, 0, 0.6)),
    "tick": ("single clock tick, close, dry", 0.5, ("tone", 2400, 0, 0.05)),
    "heartbeat": ("two slow heartbeats, deep, tense", 1.6, ("tone", 58, 0, 0.35)),
    "gasp": ("short surprised human gasp", 0.8, ("noise", 900, 4000, 0.35)),
    "wow": ("small crowd saying wow, amazed", 1.5, ("noise", 300, 2400, 1.0)),
    "magic": ("magical sparkle chime, fairy dust", 1.2, ("sweep", 1200, 3200, 0.9)),
    "glitch": ("digital glitch stutter, short", 0.6, ("noise", 2000, 9000, 0.3)),
    "bell": ("school bell ringing, short", 1.2, ("tone", 1245, 0, 1.0)),
    "click": ("mouse click, single, dry", 0.5, ("tone", 3200, 0, 0.03)),
    "splash": ("water splash, medium", 1.0, ("noise", 400, 5000, 0.7)),
    "crash": ("cartoon crash, things falling and breaking", 1.2, ("noise", 150, 7000, 0.8)),
    "laugh": ("small group laughing briefly, friendly", 1.5, ("noise", 500, 3000, 0.9)),
    "record-scratch": ("vinyl record scratch, sudden stop", 0.7, ("sweep", 1600, 300, 0.3)),
    "sparkle": ("tiny twinkle sparkle, high and short", 0.7, ("sweep", 2400, 4200, 0.4)),
    "alarm": ("alarm clock beeping, three beeps", 1.2, ("tone", 1960, 0, 0.18)),
    "wind": ("gust of wind, soft, outdoors", 1.5, ("noise", 200, 1500, 1.4)),
    "zap": ("electric zap, short spark", 0.5, ("sweep", 3000, 400, 0.18)),
}


def synth_sfx(name: str, out: Path) -> None:
    kind, f1, f2, dur = SFX[name][2]
    if kind == "tone":
        src = f"aevalsrc='0.6*sin(2*PI*{f1}*t)*exp(-{4.5 / dur:.2f}*t)+0.25*sin(2*PI*{f1 * 2.01:.0f}*t)*exp(-{7 / dur:.2f}*t)':d={dur}:s=44100"
    elif kind == "sweep":
        src = f"aevalsrc='0.5*sin(2*PI*({f1}*t+({f2}-{f1})*t*t/(2*{dur})))*min(1\\,t*60)*exp(-{2.2 / dur:.2f}*t)':d={dur}:s=44100"
    else:
        src = (f"anoisesrc=d={dur}:c=pink:r=44100:a=0.7,highpass=f={f1},lowpass=f={f2},"
               f"afade=t=in:d={dur * 0.3:.2f},afade=t=out:st={dur * 0.35:.2f}:d={dur * 0.65:.2f}")
    ffmpeg(["-f", "lavfi", "-i", src, "-ac", "1", "-q:a", "3", str(out)])


def shot_sfx(shot: dict) -> list[str]:
    v = shot.get("sfx")
    if not v:
        return []
    return [v] if isinstance(v, str) else list(v)


def cmd_sfx(a: list[str]) -> None:
    if not a:
        die("usage: sfx <slug> [--mock]")
    slug, mock = a[0], "--mock" in a
    ep = load_episode(slug)
    SFX_DIR.mkdir(exist_ok=True)
    names = sorted({n for s in ep["shots"] for n in shot_sfx(s)})
    unknown = [n for n in names if n not in SFX]
    if unknown:
        die(f"unknown sfx: {', '.join(unknown)}. Available: {', '.join(SFX)}")
    made, reused, synth = [], [], []
    key = None if mock else api_key(required=False)
    requests = need_requests() if key else None
    for n in names:
        f = SFX_DIR / f"{n}.mp3"
        if f.exists() and f.stat().st_size > 500:
            reused.append(n)
            continue
        if key:
            prompt, dur, _ = SFX[n]
            try:
                r = requests.post(f"{API}/sound-generation", headers={"xi-api-key": key, "Content-Type": "application/json"},
                                  json={"text": prompt, "duration_seconds": dur, "prompt_influence": 0.5}, timeout=180)
            except Exception as e:
                r = None
                say(f"note: sfx '{n}' request failed ({e})")
            if r is not None and r.status_code == 200 and len(r.content) > 500:
                f.write_bytes(r.content)
                made.append(f"{n} ({r.headers.get('character-cost', '?')} credits)")
                continue
            if r is not None:
                say(f"note: ElevenLabs refused sfx '{n}' ({r.status_code}: {r.text[:140]}) - using a synthesised one")
        tmp = SFX_DIR / f"{n}.synth.mp3"
        synth_sfx(n, tmp)
        synth.append(n)
    say(f"sfx for {slug}: {len(names)} needed | generated: {', '.join(made) or '-'} | reused from ./sfx: "
        f"{', '.join(reused) or '-'} | synthesised stand-ins: {', '.join(synth) or '-'}")
    if synth and not mock:
        say("stand-ins are used until a real file with the same name appears in ./sfx (run sfx again when credits are back)")


def sfx_file(name: str) -> Path | None:
    for f in (SFX_DIR / f"{name}.mp3", SFX_DIR / f"{name}.wav", SFX_DIR / f"{name}.synth.mp3"):
        if f.exists():
            return f
    return None


# ----------------------------------------------------------------------------
# mix
# ----------------------------------------------------------------------------

def loudness(path: Path) -> tuple[float, float]:
    """integrated LUFS and true peak of a file"""
    ff = exe("ffmpeg")
    p = run([ff, "-hide_banner", "-nostats", "-i", str(path), "-af", "loudnorm=print_format=json", "-f", "null", "-"],
            quiet=True)
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", p.stdout, re.S)
    if not m:
        return -99.0, -99.0
    j = json.loads(m.group(0))

    def num(v: str) -> float:
        try:
            return float(v)
        except ValueError:
            return -99.0
    return num(j["input_i"]), num(j["input_tp"])


def peak_db(path: Path) -> float:
    ff = exe("ffmpeg")
    p = run([ff, "-hide_banner", "-nostats", "-i", str(path), "-af", "volumedetect", "-f", "null", "-"], quiet=True)
    m = re.search(r"max_volume:\s*(-?[\d.]+) dB", p.stdout)
    return float(m.group(1)) if m else 0.0


VOICE_LUFS, FINAL_LUFS, SFX_PEAK, MUSIC_LUFS = -16.0, -14.0, -11.0, -31.0


def cmd_mix(a: list[str]) -> None:
    if not a:
        die("usage: mix <slug>")
    slug = a[0]
    ep = load_episode(slug)
    d = ep_dir(slug)
    timing = load_timing(slug, ep, strict=True)
    voice = d / "voice.mp3"
    total = timing["duration"] + TAIL
    mock = bool(timing.get("mock"))

    inputs = ["-i", str(voice)]
    filt = []
    v_i, _ = loudness(voice)
    gain = 0.0 if (mock or v_i < -70) else VOICE_LUFS - v_i
    filt.append(f"[0:a]aresample=48000,volume={gain:.2f}dB,apad=whole_dur={total:.3f}[v]")
    mixin = ["[v]"]
    n = 1
    placed = 0
    for i, s in enumerate(ep["shots"]):
        for k, name in enumerate(shot_sfx(s)):
            f = sfx_file(name)
            if not f:
                die(f"sound '{name}' is missing in ./sfx - run the sfx command first")
            g = SFX_PEAK - peak_db(f)
            at = int((timing["shots"][i]["start"] + 0.02 + k * 0.28) * 1000)
            inputs += ["-i", str(f)]
            filt.append(f"[{n}:a]aresample=48000,aformat=channel_layouts=mono,volume={g:.2f}dB,adelay={at}:all=1[s{n}]")
            mixin.append(f"[s{n}]")
            n += 1
            placed += 1
    music = None
    want = ep.get("music")
    if MUSIC_DIR.exists():
        tracks = sorted(p for p in MUSIC_DIR.iterdir() if p.suffix.lower() in (".mp3", ".wav", ".m4a", ".ogg"))
        if want:
            music = next((p for p in tracks if p.name == want or p.stem == want), None)
            if not music:
                die(f'music "{want}" not found in ./music')
        elif tracks and ep.get("music") is not False:
            music = tracks[0]
    if music:
        m_i, _ = loudness(music)
        g = MUSIC_LUFS - m_i if m_i > -70 else 0
        inputs += ["-stream_loop", "-1", "-i", str(music)]
        filt.append(f"[{n}:a]aresample=48000,aformat=channel_layouts=mono,volume={g:.2f}dB,atrim=0:{total:.3f},"
                    f"afade=t=in:d=0.8,afade=t=out:st={max(0, total - 1.5):.3f}:d=1.5[m]")
        mixin.append("[m]")
        n += 1
    filt.append(f"{''.join(mixin)}amix=inputs={len(mixin)}:normalize=0:duration=longest,atrim=0:{total:.3f}[mix]")
    raw = d / ".mix-raw.wav"
    ffmpeg([*inputs, "-filter_complex", ";".join(filt), "-map", "[mix]", "-ar", "48000", "-ac", "2", str(raw)])

    out = d / "audio.wav"
    if mock:
        shutil.move(str(raw), out)
        say(f"MOCK mix saved (silent voice + {placed} sfx): episodes/{slug}/audio.wav")
        return
    # bring the whole mix to the target, limit, measure; repeat until it is right
    src, lufs, tp = raw, 0.0, 0.0
    for attempt in range(1, 5):
        i_now, _ = loudness(src)
        g = FINAL_LUFS - i_now
        tmp = d / f".mix-{attempt}.wav"
        ffmpeg(["-i", str(src), "-af", f"volume={g:.2f}dB,alimiter=limit=0.82:attack=3:release=60:level=disabled",
                "-ar", "48000", str(tmp)])
        lufs, tp = loudness(tmp)
        say(f"mix pass {attempt}: {lufs:.1f} LUFS, true peak {tp:.1f} dB")
        if src != raw:
            src.unlink(missing_ok=True)
        src = tmp
        if abs(lufs - FINAL_LUFS) <= 0.7 and tp <= -1.0:
            break
    shutil.move(str(src), out)
    raw.unlink(missing_ok=True)
    good = abs(lufs - FINAL_LUFS) <= 1.0 and tp <= -0.9
    say(f"mix saved: episodes/{slug}/audio.wav  {total:.1f}s, {placed} sfx{', music ' + music.name if music else ''}, "
        f"loudness {lufs:.1f} LUFS (target {FINAL_LUFS:.0f}), peak {tp:.1f} dB -> {'OK' if good else 'CHECK BY EAR'}")


# ----------------------------------------------------------------------------
# render
# ----------------------------------------------------------------------------

def cmd_render(a: list[str]) -> None:
    if not a:
        die("usage: render <slug> [--draft]")
    slug, draft = a[0], "--draft" in a
    rc, _ = lint(slug, strict_timing=True)
    if rc and "--force" not in a:
        die("the episode still has errors (see above). Fix them first, or add --force to render anyway.")
    props, ep, timing = write_props(slug, strict_timing=True)
    d = ep_dir(slug)
    audio = d / "audio.wav"
    if not audio.exists():
        die("no audio.wav - run the mix command first")
    silent = d / ".video-silent.mp4"
    say(f"rendering {timing['duration'] + TAIL:.0f}s of video{' (draft, half size)' if draft else ''} - this takes a few minutes ...")
    args = ["render", "src/index.ts", "Episode", str(silent), f"--props={props}", "--codec=h264",
            "--crf=" + ("26" if draft else "18"), "--pixel-format=yuv420p", "--muted"]
    if draft:
        args.append("--scale=0.5")
    remotion(args)
    out = d / (f"{slug}-draft.mp4" if draft else f"{slug}.mp4")
    ffmpeg(["-i", str(silent), "-i", str(audio), "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac",
            "-b:a", "192k", "-movflags", "+faststart", "-shortest", str(out)])
    silent.unlink(missing_ok=True)
    fp = exe("ffprobe")
    info = run([fp, "-v", "error", "-show_entries", "stream=codec_type,width,height:format=duration,size",
                "-of", "json", str(out)], quiet=True).stdout
    j = json.loads(info)
    v = next(s for s in j["streams"] if s["codec_type"] == "video")
    has_audio = any(s["codec_type"] == "audio" for s in j["streams"])
    say(f"\nDONE: episodes/{slug}/{out.name}  {v['width']}x{v['height']}, {float(j['format']['duration']):.1f}s, "
        f"{int(j['format']['size']) / 1e6:.1f} MB, audio: {'yes' if has_audio else 'NO'}"
        + ("  [MOCK VOICE - silent narration]" if timing.get("mock") else ""))


def cmd_build(a: list[str]) -> None:
    if not a:
        die("usage: build <slug> [--mock] [--draft]")
    slug = a[0]
    flags = [x for x in a[1:] if x.startswith("--")]
    cmd_voice([slug] + [f for f in flags if f in ("--mock", "--force")])
    cmd_sfx([slug] + [f for f in flags if f == "--mock"])
    cmd_mix([slug])
    cmd_render([slug] + [f for f in flags if f in ("--draft", "--force")])


COMMANDS = {
    "setup": cmd_setup, "status": cmd_status, "new": cmd_new, "check": cmd_check, "board": cmd_board,
    "frame": cmd_frame, "sheet": cmd_sheet, "voice": cmd_voice, "sfx": cmd_sfx, "mix": cmd_mix,
    "render": cmd_render, "build": cmd_build,
}

if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        say(__doc__)
        sys.exit(0 if len(sys.argv) < 2 else 2)
    if not (ROOT / ".opencode").exists() and not (ROOT / "episodes").exists():
        say("note: run this from your cartoons folder (the one that contains .opencode and .env)")
    COMMANDS[sys.argv[1]](sys.argv[2:])
