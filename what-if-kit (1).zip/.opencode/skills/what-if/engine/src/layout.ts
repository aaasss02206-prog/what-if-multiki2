// Pure geometry for the what-if engine. No React here: the same maths drives
// the renderer (Character.tsx, Shot.tsx) and the storyboard linter (tools/lint.ts),
// so what the linter measures is exactly what ends up on screen.

export const W = 1920;
export const H = 1080;
export const GROUND = 900;

export type Pt = {x: number; y: number};
export type Box = {x: number; y: number; w: number; h: number};

export type Pose = {
  lean?: number; // torso lean, degrees, + = towards facing side
  head?: number; // head tilt, + = nod forward
  armF: [number, number]; // front arm: shoulder angle, elbow bend
  armB: [number, number]; // back arm
  legF: [number, number]; // front leg: hip angle, knee bend (usually <= 0)
  legB: [number, number];
  rot?: number; // whole-body rotation around the hip (90 = lying on the back)
  dy?: number; // lift above the ground in px (negative = up); sets "air"
  air?: boolean;
};

const P = (
  armF: [number, number],
  armB: [number, number],
  legF: [number, number] = [7, 0],
  legB: [number, number] = [-7, 0],
  extra: Partial<Pose> = {},
): Pose => ({armF, armB, legF, legB, ...extra});

// All poses are authored for a figure FACING RIGHT. Angles: 0 = straight down,
// 90 = pointing right (forward), 180 = straight up, negative = backwards.
export const POSES: Record<string, Pose> = {
  stand: P([10, 8], [-10, -8]),
  relaxed: P([14, 20], [-14, -20], [9, 0], [-9, 0], {lean: 2}),
  point: P([88, 4], [-12, -10], [10, 0], [-8, 0], {lean: 4}),
  'point-up': P([138, 12], [-12, -10]),
  'point-back': P([-88, -4], [12, 10], [8, 0], [-10, 0], {head: -4}),
  wave: P([125, 25], [-12, -10]),
  think: P([40, 130], [-20, 70], [7, 0], [-7, 0], {head: 8}),
  shrug: P([42, 74], [-42, -74], [9, 0], [-9, 0], {head: -4}),
  cheer: P([135, 5], [-135, -5], [12, 0], [-12, 0], {head: -8}),
  facepalm: P([34, 142], [-10, -8], [7, 0], [-7, 0], {head: 14, lean: 4}),
  hold: P([48, 62], [-10, -8]),
  'hold-up': P([132, 6], [-12, -10], [9, 0], [-9, 0], {head: -12}),
  'hold-out': P([86, 6], [-12, -10], [10, 0], [-8, 0]),
  carry: P([58, 34], [40, 52], [8, 0], [-8, 0], {lean: -4}),
  reach: P([100, 2], [-30, -20], [16, 0], [-14, 0], {lean: 12}),
  catch: P([118, 18], [70, 40], [14, -8], [-14, 0], {lean: -6, head: -8}),
  throw: P([120, 20], [-40, -30], [18, 0], [-16, 0], {lean: 12}),
  phone: P([30, 128], [-10, -8], [7, 0], [-7, 0], {head: 14}),
  read: P([44, 84], [30, 96], [7, 0], [-7, 0], {head: 16}),
  type: P([56, 36], [44, 44], [84, -84], [78, -84], {head: 8, lean: 6}),
  sit: P([20, 50], [-6, 40], [86, -86], [80, -86]),
  'sit-ground': P([24, 30], [-40, -10], [84, -30], [70, -60], {lean: -10}),
  kneel: P([10, 30], [-10, -20], [80, -150], [-10, -90], {lean: 6}),
  crouch: P([40, 60], [-30, 50], [70, -120], [50, -120], {lean: 24, head: -10}),
  walk: P([24, 18], [-24, -12], [24, -6], [-24, -18]),
  run: P([50, 84], [-56, 80], [50, -30], [-40, -70], {lean: 14}),
  sneak: P([40, 70], [-10, 60], [30, -40], [-20, -40], {lean: 18, head: -10}),
  jump: P([135, 8], [-135, -8], [40, -70], [-20, -70], {dy: -150}),
  fly: P([100, 4], [80, 4], [-70, 0], [-82, 0], {rot: 0, lean: 64, dy: -330, head: -40}),
  float: P([40, 20], [-40, -20], [14, -20], [-14, -20], {dy: -110, head: -6}),
  fall: P([150, 20], [-160, -20], [50, -30], [-40, -20], {rot: 64, dy: -160}),
  lie: P([10, 8], [-10, -8], [4, 0], [-4, 0], {rot: 90}),
  sleep: P([30, 40], [-10, -8], [10, -20], [-4, -10], {rot: 90}),
  scared: P([56, 138], [-56, -138], [14, -10], [-14, -10], {lean: -10, head: -6}),
  'cover-eyes': P([36, 140], [-36, -140], [7, 0], [-7, 0], {head: 6}),
  'hands-hips': P([52, -104], [-52, 104], [11, 0], [-11, 0]),
  cross: P([28, 118], [-28, -118], [9, 0], [-9, 0]),
  strong: P([92, 92], [-92, -92], [14, 0], [-14, 0], {head: -4}),
  punch: P([92, 2], [-50, 96], [34, -14], [-30, 0], {lean: 16}),
  kick: P([-30, -40], [50, 60], [86, -8], [-10, 0], {lean: -14}),
  push: P([86, 2], [80, 6], [30, -10], [-32, 0], {lean: 20}),
  pull: P([70, 10], [62, 14], [-20, 0], [26, -30], {lean: -22}),
  sad: P([6, 4], [-6, -4], [5, 0], [-5, 0], {lean: 8, head: 22}),
  'look-up': P([10, 8], [-10, -8], [7, 0], [-7, 0], {head: -24, lean: -4}),
  bow: P([20, 10], [-4, 10], [7, 0], [-7, 0], {lean: 48, head: 20}),
  dance: P([125, 30], [-70, -80], [20, -20], [-16, 0], {lean: -6}),
  dizzy: P([60, 30], [-70, -20], [16, 0], [-16, 0], {lean: 8, head: 16}),
  proud: P([52, -104], [-135, -5], [11, 0], [-11, 0], {head: -8}),
  listen: P([30, 150], [-10, -8], [7, 0], [-7, 0], {head: -6, lean: 4}),
  count: P([44, 96], [34, 106], [7, 0], [-7, 0], {head: 12}),
  drive: P([70, 20], [62, 26], [84, -70], [78, -70], {lean: -6}),
  eat: P([36, 132], [-10, 40], [7, 0], [-7, 0], {head: 6}),
};

// Poses that loop on their own (phase 0..1).
export const CYCLES = new Set(['walk', 'run', 'sneak', 'wave', 'dance', 'type', 'cheer']);

const BONE = {
  headR: 52,
  hip: 136, // hip height above the feet when standing
  torso: 116,
  upper: 62,
  fore: 60,
  thigh: 68,
  shin: 68,
  shoulderDrop: 16,
};
export const STROKE = 13;
export const HEAD_R = BONE.headR;
export const FIGURE_H = BONE.hip + BONE.torso + BONE.headR * 2 + 2;

const rad = (d: number) => (d * Math.PI) / 180;
const dir = (deg: number): Pt => ({x: Math.sin(rad(deg)), y: Math.cos(rad(deg))});
const add = (a: Pt, b: Pt, k = 1): Pt => ({x: a.x + b.x * k, y: a.y + b.y * k});
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const lerp2 = (a: [number, number], b: [number, number], t: number): [number, number] => [
  lerp(a[0], b[0], t),
  lerp(a[1], b[1], t),
];

export const blendPose = (a: Pose, b: Pose, t: number): Pose => ({
  lean: lerp(a.lean ?? 0, b.lean ?? 0, t),
  head: lerp(a.head ?? 0, b.head ?? 0, t),
  armF: lerp2(a.armF, b.armF, t),
  armB: lerp2(a.armB, b.armB, t),
  legF: lerp2(a.legF, b.legF, t),
  legB: lerp2(a.legB, b.legB, t),
  rot: lerp(a.rot ?? 0, b.rot ?? 0, t),
  dy: lerp(a.dy ?? 0, b.dy ?? 0, t),
});

// Looping variations for cycle poses. `ph` is a phase in turns.
export const cyclePose = (name: string, ph: number): Pose => {
  const s = Math.sin(ph * Math.PI * 2);
  const c = Math.cos(ph * Math.PI * 2);
  const base = POSES[name];
  switch (name) {
    case 'walk':
      return {
        ...base,
        armF: [-22 * s, 14],
        armB: [22 * s, 14],
        legF: [26 * s, -22 * Math.max(0, -c)],
        legB: [-26 * s, -22 * Math.max(0, c)],
        lean: 3,
      };
    case 'run':
      return {
        ...base,
        armF: [-58 * s, 86],
        armB: [58 * s, 86],
        legF: [48 * s, -70 * Math.max(0.1, -c)],
        legB: [-48 * s, -70 * Math.max(0.1, c)],
        lean: 15,
        dy: -10 * Math.abs(c),
      };
    case 'sneak':
      return {
        ...base,
        legF: [30 * s, -40 - 20 * Math.max(0, -c)],
        legB: [-30 * s, -40 - 20 * Math.max(0, c)],
      };
    case 'wave':
      return {...base, armF: [125, 25 + 24 * s]};
    case 'dance':
      return {
        ...base,
        armF: [122 + 14 * s, 30],
        armB: [-70 - 30 * s, -80],
        lean: -6 * s,
        dy: -14 * Math.abs(s),
      };
    case 'type':
      return {...base, armF: [56 + 4 * s, 36], armB: [44 - 4 * s, 44]};
    case 'cheer':
      return {...base, armF: [135 + 8 * s, 5], armB: [-135 - 8 * s, -5], dy: -26 * Math.abs(s)};
    default:
      return base;
  }
};

export type Joints = {
  hip: Pt;
  neck: Pt;
  head: Pt;
  shoulder: Pt;
  elbowF: Pt;
  handF: Pt;
  elbowB: Pt;
  handB: Pt;
  kneeF: Pt;
  footF: Pt;
  kneeB: Pt;
  footB: Pt;
  headR: number;
  headAngle: number; // degrees, in local (unflipped) space
};

// Joints in LOCAL space: origin at the ground contact point, y up is negative,
// figure facing right, scale 1.
export const solve = (pose: Pose): Joints => {
  const lean = pose.lean ?? 0;
  const up = dir(180 - lean); // torso direction from hip to neck
  const hip0: Pt = {x: 0, y: 0};
  const neck0 = add(hip0, up, BONE.torso);
  const headAngle = lean + (pose.head ?? 0);
  const head0 = add(neck0, dir(180 - headAngle), BONE.headR + 2);
  const shoulder0 = add(hip0, up, BONE.torso - BONE.shoulderDrop);
  const limb = (from: Pt, a: number, b: number, l1: number, l2: number): [Pt, Pt] => {
    const mid = add(from, dir(a), l1);
    return [mid, add(mid, dir(a + b), l2)];
  };
  const [elbowF, handF] = limb(shoulder0, pose.armF[0] + lean * 0.5, pose.armF[1], BONE.upper, BONE.fore);
  const [elbowB, handB] = limb(shoulder0, pose.armB[0] + lean * 0.5, pose.armB[1], BONE.upper, BONE.fore);
  const [kneeF, footF] = limb(hip0, pose.legF[0], pose.legF[1], BONE.thigh, BONE.shin);
  const [kneeB, footB] = limb(hip0, pose.legB[0], pose.legB[1], BONE.thigh, BONE.shin);

  let j: Joints = {
    hip: hip0,
    neck: neck0,
    head: head0,
    shoulder: shoulder0,
    elbowF,
    handF,
    elbowB,
    handB,
    kneeF,
    footF,
    kneeB,
    footB,
    headR: BONE.headR,
    headAngle,
  };

  const rot = pose.rot ?? 0;
  if (rot) {
    const r = rad(rot);
    const cs = Math.cos(r);
    const sn = Math.sin(r);
    const turn = (p: Pt): Pt => ({x: p.x * cs - p.y * sn, y: p.x * sn + p.y * cs});
    j = {
      ...j,
      hip: turn(j.hip),
      neck: turn(j.neck),
      head: turn(j.head),
      shoulder: turn(j.shoulder),
      elbowF: turn(j.elbowF),
      handF: turn(j.handF),
      elbowB: turn(j.elbowB),
      handB: turn(j.handB),
      kneeF: turn(j.kneeF),
      footF: turn(j.footF),
      kneeB: turn(j.kneeB),
      footB: turn(j.footB),
      headAngle: j.headAngle - rot,
    };
  }

  // Put the lowest point on the ground, then apply the lift.
  const pts = [j.hip, j.neck, j.elbowF, j.handF, j.elbowB, j.handB, j.kneeF, j.footF, j.kneeB, j.footB];
  let low = Math.max(...pts.map((p) => p.y), j.head.y + BONE.headR - STROKE / 2);
  low += STROKE / 2;
  const shift = -low + (pose.dy ?? 0);
  const mv = (p: Pt): Pt => ({x: p.x, y: p.y + shift});
  return {
    ...j,
    hip: mv(j.hip),
    neck: mv(j.neck),
    head: mv(j.head),
    shoulder: mv(j.shoulder),
    elbowF: mv(j.elbowF),
    handF: mv(j.handF),
    elbowB: mv(j.elbowB),
    handB: mv(j.handB),
    kneeF: mv(j.kneeF),
    footF: mv(j.footF),
    kneeB: mv(j.kneeB),
    footB: mv(j.footB),
  };
};

// ---------- episode schema ----------

export type ActorSpec = {
  who: string;
  x?: number; // 0..100, percent of the frame width
  toX?: number;
  y?: number; // px offset from the ground, negative = up
  scale?: number;
  toScale?: number;
  face?: 'left' | 'right';
  pose?: string;
  toPose?: string;
  switchAt?: number; // 0..1, when pose -> toPose
  mood?: string;
  toMood?: string;
  hold?: string; // prop in the front hand
  holdSize?: number;
  label?: string | {text: string; color?: string; from?: number; to?: number; prefix?: string; suffix?: string};
  bubble?: {type?: 'thought' | 'speech'; text?: string; icon?: string};
  motion?: 'none' | 'jump' | 'shake' | 'nod' | 'float' | 'spin' | 'pop' | 'tremble';
  ghost?: boolean; // semi-transparent (future self, memory)
  glow?: string; // coloured aura
  z?: number;
};

export type PropSpec = {
  type: string;
  x: number; // percent
  y?: number | 'ground'; // percent of height, or sit on the ground
  toX?: number;
  toY?: number | 'ground';
  size?: number; // px width
  toSize?: number;
  arc?: number; // px of arc height while moving
  rot?: number;
  spin?: number; // full turns over the shot
  layer?: 'back' | 'front';
  cover?: boolean; // allowed to cover a face (masks, helmets)
  text?: string; // for sign / screen-like props
};

export type CameraSpec = {
  size?: 'wide' | 'medium' | 'close' | 'extreme';
  on?: number | string | {x: number; y: number};
  move?: 'static' | 'push' | 'pull' | 'pan-left' | 'pan-right' | 'shake' | 'drift';
};

export type TextSpec = {
  value: string;
  pos?: 'top' | 'center' | 'bottom';
  style?: 'title' | 'impact' | 'note';
  color?: string;
  count?: {from: number; to: number; prefix?: string; suffix?: string};
};

export type ShotSpec = {
  id?: number;
  beat?: 'hook' | 'rules' | 'small' | 'bigger' | 'dark' | 'fact' | 'question';
  say: string;
  pause?: number;
  bg?: string;
  time?: 'day' | 'sunset' | 'night' | 'dawn';
  camera?: CameraSpec;
  actors?: ActorSpec[];
  props?: PropSpec[];
  crowd?: {count?: number; labels?: string[]; scale?: number; pose?: string};
  text?: TextSpec;
  source?: string;
  fx?: string[];
  sfx?: string | string[];
  thumb?: boolean;
};

export type Episode = {
  slug: string;
  title: string;
  language?: string;
  hero: string;
  subtitles?: 'off' | 'words';
  shots: ShotSpec[];
};

export const ZOOM: Record<string, number> = {wide: 1, medium: 1.5, close: 2.25, extreme: 3.1};

const ease = (t: number) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
export const BASE_SCALE = 1.2; // scale 1 in an episode file = a figure about 430 px tall
export const clamp01 = (t: number) => Math.max(0, Math.min(1, t));

export type ActorState = {
  spec: ActorSpec;
  x: number;
  groundY: number;
  scale: number;
  flip: boolean;
  joints: Joints; // local
  poseName: string;
  mood: string;
};

const propSize: Record<string, [number, number]> = {};
export const registerPropSize = (name: string, w: number, h: number) => {
  propSize[name] = [w, h];
};
export const propAspect = (name: string) => {
  const s = propSize[name];
  return s ? s[1] / s[0] : 1;
};

// World-space point of a local joint.
export const toWorld = (a: ActorState, p: Pt): Pt => ({
  x: a.x + (a.flip ? -p.x : p.x) * a.scale,
  y: a.groundY + p.y * a.scale,
});

export const actorAt = (spec: ActorSpec, t: number, seconds: number, idx = 0): ActorState => {
  const k = clamp01(t);
  const move = spec.toX !== undefined ? ease(k) : 0;
  const xPct = lerp(spec.x ?? 50, spec.toX ?? spec.x ?? 50, move);
  const scale = BASE_SCALE * lerp(spec.scale ?? 1, spec.toScale ?? spec.scale ?? 1, ease(k));
  const sw = spec.switchAt ?? 0.5;
  const poseName = spec.toPose && k >= sw ? spec.toPose : spec.pose ?? 'stand';
  const from = POSES[spec.pose ?? 'stand'] ?? POSES.stand;
  const getPose = (name: string): Pose => {
    if (CYCLES.has(name)) {
      const speed = name === 'run' ? 2.6 : name === 'walk' ? 1.5 : name === 'type' ? 5 : 1.6;
      return cyclePose(name, seconds * speed + idx * 0.37);
    }
    return POSES[name] ?? POSES.stand;
  };
  let pose = getPose(spec.pose ?? 'stand');
  if (spec.toPose) {
    const blend = clamp01((k - sw) / 0.12);
    pose = blendPose(pose, getPose(spec.toPose), ease(blend));
  }
  // idle breathing so nobody is ever a frozen drawing
  const breathe = Math.sin(seconds * 2.2 + idx * 1.7);
  pose = {
    ...pose,
    armF: [pose.armF[0] + breathe * 1.6, pose.armF[1]],
    armB: [pose.armB[0] - breathe * 1.6, pose.armB[1]],
    head: (pose.head ?? 0) + breathe * 1.2,
  };
  let dy = 0;
  let dx = 0;
  switch (spec.motion) {
    case 'jump':
      dy = -Math.abs(Math.sin(seconds * 6.5)) * 60;
      break;
    case 'shake':
      dx = Math.sin(seconds * 46) * 7;
      break;
    case 'tremble':
      dx = Math.sin(seconds * 60) * 3;
      break;
    case 'nod':
      pose = {...pose, head: (pose.head ?? 0) + Math.sin(seconds * 9) * 10};
      break;
    case 'float':
      dy = -40 + Math.sin(seconds * 2.4) * 16;
      break;
    default:
      break;
  }
  void from;
  const joints = solve(pose);
  let face = spec.face ?? 'right';
  if (spec.toX !== undefined && spec.face === undefined) {
    face = (spec.toX ?? 0) >= (spec.x ?? 50) ? 'right' : 'left';
  }
  const mood = spec.toMood && k >= sw ? spec.toMood : spec.mood ?? 'neutral';
  return {
    spec,
    x: (xPct / 100) * W + dx,
    groundY: GROUND + (spec.y ?? 0) + dy,
    scale,
    flip: face === 'left',
    joints,
    poseName,
    mood,
  };
};

export const headBox = (a: ActorState): Box => {
  const c = toWorld(a, a.joints.head);
  const r = a.joints.headR * a.scale;
  return {x: c.x - r, y: c.y - r, w: r * 2, h: r * 2};
};

export const bodyBox = (a: ActorState): Box => {
  const j = a.joints;
  const pts = [j.hip, j.neck, j.elbowF, j.handF, j.elbowB, j.handB, j.kneeF, j.footF, j.kneeB, j.footB].map((p) =>
    toWorld(a, p),
  );
  const hb = headBox(a);
  const xs = pts.map((p) => p.x).concat([hb.x, hb.x + hb.w]);
  const ys = pts.map((p) => p.y).concat([hb.y, hb.y + hb.h]);
  const x = Math.min(...xs);
  const y = Math.min(...ys);
  return {x, y, w: Math.max(...xs) - x, h: Math.max(...ys) - y};
};

export const heldPropBox = (a: ActorState): Box | null => {
  if (!a.spec.hold) return null;
  const h = toWorld(a, a.joints.handF);
  const w = (a.spec.holdSize ?? 84) * a.scale;
  const hh = w * propAspect(a.spec.hold);
  return {x: h.x - w / 2, y: h.y - hh / 2, w, h: hh};
};

export const labelText = (l: ActorSpec['label'], t = 1): string => {
  if (!l) return '';
  if (typeof l === 'string') return l;
  if (l.from !== undefined && l.to !== undefined) {
    const v = lerp(l.from, l.to, clamp01(t / 0.7));
    return `${l.prefix ?? ''}${formatNumber(v, l.to)}${l.suffix ?? ''}`;
  }
  return l.text;
};

export const formatNumber = (v: number, target: number): string => {
  const whole = Number.isInteger(target);
  const n = whole ? Math.round(v) : Math.round(v * 10) / 10;
  return n.toLocaleString('en-US', whole ? {} : {minimumFractionDigits: 1, maximumFractionDigits: 1});
};

export const labelBox = (a: ActorState, t = 1): Box | null => {
  const txt = labelText(a.spec.label, t);
  if (!txt) return null;
  const hb = headBox(a);
  const fs = 44 * Math.max(0.7, a.scale);
  const w = txt.length * fs * 0.6 + fs * 1.1;
  const h = fs * 1.5;
  return {x: hb.x + hb.w / 2 - w / 2, y: hb.y - h - 18 * a.scale, w, h};
};

export const bubbleBox = (a: ActorState): Box | null => {
  const b = a.spec.bubble;
  if (!b) return null;
  const hb = headBox(a);
  const txt = b.text ?? '';
  const w = b.icon ? 190 : Math.min(520, Math.max(170, txt.length * 25 + 70));
  const lines = b.icon ? 1 : Math.ceil((txt.length * 25 + 70) / 520);
  const h = b.icon ? 170 : 70 + lines * 48;
  const side = a.flip ? -1 : 1;
  const x = hb.x + hb.w / 2 + side * (hb.w * 0.6) - (side < 0 ? w : 0);
  return {x, y: hb.y - h - 6, w, h};
};

const pctY = (y: number | 'ground' | undefined, h: number): number => {
  if (y === 'ground' || y === undefined) return GROUND - h / 2;
  return (y / 100) * H;
};

export const propAt = (p: PropSpec, t: number): {cx: number; cy: number; w: number; h: number; rot: number} => {
  const k = ease(clamp01(t));
  const w = lerp(p.size ?? 120, p.toSize ?? p.size ?? 120, k);
  const h = w * propAspect(p.type);
  const x0 = (p.x / 100) * W;
  const x1 = ((p.toX ?? p.x) / 100) * W;
  const y0 = pctY(p.y, h);
  const y1 = pctY(p.toY ?? p.y, h);
  const moving = p.toX !== undefined || p.toY !== undefined;
  const arc = moving ? -(p.arc ?? 0) * Math.sin(Math.PI * clamp01(t)) : 0;
  return {
    cx: lerp(x0, x1, moving ? clamp01(t) : 0),
    cy: lerp(y0, y1, moving ? clamp01(t) : 0) + arc,
    w,
    h,
    rot: (p.rot ?? 0) + (p.spin ?? 0) * 360 * clamp01(t),
  };
};

export const propBox = (p: PropSpec, t: number): Box => {
  const s = propAt(p, t);
  return {x: s.cx - s.w / 2, y: s.cy - s.h / 2, w: s.w, h: s.h};
};

export type Cam = {zoom: number; cx: number; cy: number};

export const resolveFocus = (shot: ShotSpec, actors: ActorState[], hero: string): Pt => {
  const on = shot.camera?.on;
  const size = shot.camera?.size ?? 'wide';
  let a: ActorState | undefined;
  if (typeof on === 'object' && on) return {x: (on.x / 100) * W, y: (on.y / 100) * H};
  if (typeof on === 'number') a = actors[on];
  else if (typeof on === 'string' && on !== 'center') a = actors.find((s) => s.spec.who === on);
  else if (on === undefined) a = actors.find((s) => s.spec.who === hero) ?? actors[0];
  if (!a || on === 'center') return {x: W / 2, y: H / 2};
  const head = toWorld(a, a.joints.head);
  const hip = toWorld(a, a.joints.hip);
  if (size === 'close' || size === 'extreme') return {x: head.x, y: head.y + 10 * a.scale};
  if (size === 'medium') return {x: (head.x + hip.x) / 2, y: head.y + (hip.y - head.y) * 0.45};
  return {x: W / 2, y: H / 2};
};

export const cameraAt = (shot: ShotSpec, focus: Pt, t: number, seconds: number): Cam => {
  const size = shot.camera?.size ?? 'wide';
  const move = shot.camera?.move ?? 'static';
  const k = clamp01(t);
  let zoom = ZOOM[size] ?? 1;
  let cx = focus.x;
  let cy = focus.y;
  if (move === 'push') zoom *= lerp(1, 1.1, k);
  if (move === 'pull') zoom *= lerp(1.1, 1, k);
  if (move === 'drift') zoom *= lerp(1.02, 1.06, k);
  if (move === 'pan-left') cx += lerp(70, -70, k) / zoom;
  if (move === 'pan-right') cx += lerp(-70, 70, k) / zoom;
  if (move === 'shake') {
    cx += Math.sin(seconds * 53) * 9;
    cy += Math.cos(seconds * 47) * 7;
  }
  // pans on a wide shot need a little head-room
  if ((move === 'pan-left' || move === 'pan-right' || move === 'shake') && zoom < 1.08) zoom = 1.08;
  const halfW = W / (2 * zoom);
  const halfH = H / (2 * zoom);
  cx = Math.max(halfW, Math.min(W - halfW, cx));
  cy = Math.max(halfH, Math.min(H - halfH, cy));
  return {zoom, cx, cy};
};

export const viewRect = (c: Cam): Box => ({
  x: c.cx - W / (2 * c.zoom),
  y: c.cy - H / (2 * c.zoom),
  w: W / c.zoom,
  h: H / c.zoom,
});

export const worldToScreen = (c: Cam, b: Box): Box => ({
  x: (b.x - c.cx) * c.zoom + W / 2,
  y: (b.y - c.cy) * c.zoom + H / 2,
  w: b.w * c.zoom,
  h: b.h * c.zoom,
});

export const overlap = (a: Box, b: Box): number => {
  const w = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
  const h = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
  return w > 0 && h > 0 ? w * h : 0;
};

export const insideFraction = (b: Box, frame: Box): number => (b.w * b.h > 0 ? overlap(b, frame) / (b.w * b.h) : 1);

export const TEXT_STYLE: Record<string, {size: number; maxChars: number}> = {
  title: {size: 104, maxChars: 30},
  impact: {size: 150, maxChars: 16},
  note: {size: 56, maxChars: 52},
};

// Screen-space box of the on-screen text.
export const textBox = (t: TextSpec, progress = 1): Box => {
  const st = TEXT_STYLE[t.style ?? 'title'];
  let value = t.value;
  if (t.count) value = `${t.count.prefix ?? ''}${formatNumber(t.count.to, t.count.to)}${t.count.suffix ?? ''}`;
  void progress;
  const perLine = st.maxChars;
  const lines = Math.max(1, Math.ceil(value.length / perLine));
  const longest = Math.min(value.length, perLine);
  const w = Math.min(W * 0.92, longest * st.size * 0.56 + 80);
  const h = lines * st.size * 1.12 + 30;
  const pos = t.pos ?? 'top';
  const y = pos === 'top' ? 60 : pos === 'bottom' ? H - h - 96 : (H - h) / 2;
  return {x: (W - w) / 2, y, w, h};
};

export const mergeTiming = (
  ep: Episode,
  timing: {shots?: {start: number; end: number}[]} | null,
  fps: number,
): {from: number; frames: number}[] => {
  const CPS = 14.5; // characters of English narration per second, used before the voice exists
  let cursor = 0;
  return ep.shots.map((s, i) => {
    const t = timing?.shots?.[i];
    let start = cursor;
    let end = cursor + Math.max(0.9, s.say.trim().length / CPS) + (s.pause ?? 0);
    if (t) {
      start = t.start;
      end = t.end;
    }
    cursor = end;
    const from = Math.round(start * fps);
    return {from, frames: Math.max(6, Math.round(end * fps) - from)};
  });
};

export const MOODS = ['neutral', 'happy', 'laugh', 'sad', 'cry', 'shock', 'scared', 'angry', 'smug', 'think', 'sleepy', 'wink', 'love', 'dead', 'determined'];
export const BEATS = ['hook', 'rules', 'small', 'bigger', 'dark', 'fact', 'question'];
export const SFX_NAMES = ['whoosh', 'pop', 'ding', 'boing', 'thud', 'rise', 'drop', 'cash', 'tick', 'heartbeat', 'gasp', 'wow', 'magic', 'glitch', 'bell', 'click', 'splash', 'crash', 'laugh', 'record-scratch', 'sparkle', 'alarm', 'wind', 'zap'];
