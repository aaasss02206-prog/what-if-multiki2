import React from 'react';
import {ActorState, Pt, STROKE} from './layout';
import {Prop} from './props';

// One rig draws everybody. A "character" is only a row of wardrobe settings,
// which is why a hero looks identical in every shot of every episode.
export type CharacterDef = {
  name?: string;
  line?: string; // body line colour
  skin?: string; // head fill
  hair?: 'none' | 'short' | 'spiky' | 'ponytail' | 'bob' | 'long' | 'bun' | 'curly' | 'cap' | 'beanie' | 'tophat';
  hairColor?: string;
  top?: 'none' | 'tshirt' | 'hoodie' | 'sweater' | 'raincoat' | 'suit' | 'labcoat' | 'dress' | 'tank' | 'jacket';
  topColor?: string;
  bottom?: 'none' | 'pants' | 'shorts' | 'skirt';
  bottomColor?: string;
  shoes?: 'none' | 'sneakers' | 'boots';
  shoesColor?: string;
  accessory?: 'none' | 'glasses' | 'scarf' | 'backpack' | 'headphones' | 'crown' | 'tie' | 'bow' | 'cape' | 'sunglasses';
  accessoryColor?: string;
};

const INK = '#1b1b22';
const HR = 46; // the head is drawn in a 46-px design space and scaled to the rig
const seg = (a: Pt, b: Pt) => `M${a.x.toFixed(1)} ${a.y.toFixed(1)}L${b.x.toFixed(1)} ${b.y.toFixed(1)}`;
const sub = (a: Pt, b: Pt): Pt => ({x: a.x - b.x, y: a.y - b.y});
const norm = (v: Pt): Pt => {
  const l = Math.hypot(v.x, v.y) || 1;
  return {x: v.x / l, y: v.y / l};
};
const along = (a: Pt, d: Pt, k: number): Pt => ({x: a.x + d.x * k, y: a.y + d.y * k});

const Face: React.FC<{mood: string; r: number; blink: boolean; line: string}> = ({mood, r, blink, line}) => {
  const ex = 11; // faces look towards the facing side
  const gap = 15;
  const ey = -5;
  const eye = (cx: number, ry = 8, rx = 5.6) => <ellipse cx={cx} cy={ey} rx={rx} ry={blink ? 1.2 : ry} fill={line} />;
  const stroke = {stroke: line, strokeWidth: 4.5, strokeLinecap: 'round' as const, fill: 'none'};
  let eyes: React.ReactNode = (
    <>
      {eye(ex - gap)}
      {eye(ex + gap)}
    </>
  );
  let mouth: React.ReactNode = <path d={`M${ex - 9} 18h18`} {...stroke} />;
  let brows: React.ReactNode = null;
  let extra: React.ReactNode = null;
  const arcEyes = (
    <>
      <path d={`M${ex - gap - 7} ${ey + 2}q7 -9 14 0`} {...stroke} />
      <path d={`M${ex + gap - 7} ${ey + 2}q7 -9 14 0`} {...stroke} />
    </>
  );
  switch (mood) {
    case 'happy':
      mouth = <path d={`M${ex - 13} 14q13 15 26 0`} {...stroke} />;
      break;
    case 'laugh':
      eyes = arcEyes;
      mouth = <path d={`M${ex - 14} 12q14 22 28 0z`} fill={line} stroke={line} strokeWidth={4} strokeLinejoin="round" />;
      break;
    case 'sad':
      brows = <path d={`M${ex - gap - 8} ${ey - 13}l13 -6M${ex + gap + 8} ${ey - 13}l-13 -6`} {...stroke} />;
      mouth = <path d={`M${ex - 11} 22q11 -11 22 0`} {...stroke} />;
      break;
    case 'cry':
      eyes = arcEyes;
      mouth = <path d={`M${ex - 11} 23q11 -12 22 0`} {...stroke} />;
      extra = <path d={`M${ex - gap} ${ey + 8}v16M${ex + gap} ${ey + 8}v16`} stroke="#5ab8ff" strokeWidth={6} strokeLinecap="round" />;
      break;
    case 'shock':
      eyes = (
        <>
          <circle cx={ex - gap} cy={ey} r={9.5} fill="#fff" stroke={line} strokeWidth={4} />
          <circle cx={ex + gap} cy={ey} r={9.5} fill="#fff" stroke={line} strokeWidth={4} />
          <circle cx={ex - gap + 1} cy={ey} r={3.4} fill={line} />
          <circle cx={ex + gap + 1} cy={ey} r={3.4} fill={line} />
        </>
      );
      mouth = <ellipse cx={ex} cy={21} rx={8} ry={10} fill={line} />;
      break;
    case 'scared':
      eyes = (
        <>
          <circle cx={ex - gap} cy={ey} r={9} fill="#fff" stroke={line} strokeWidth={4} />
          <circle cx={ex + gap} cy={ey} r={9} fill="#fff" stroke={line} strokeWidth={4} />
          <circle cx={ex - gap} cy={ey + 1} r={3} fill={line} />
          <circle cx={ex + gap} cy={ey + 1} r={3} fill={line} />
        </>
      );
      brows = <path d={`M${ex - gap - 8} ${ey - 15}l13 -5M${ex + gap + 8} ${ey - 15}l-13 -5`} {...stroke} />;
      mouth = <path d={`M${ex - 13} 20q4 -6 8 0t9 0 9 0`} {...stroke} />;
      extra = <path d={`M${-r + 12} -14q-7 12 0 16 7 -4 0 -16z`} fill="#5ab8ff" />;
      break;
    case 'angry':
      brows = <path d={`M${ex - gap - 9} ${ey - 17}l15 8M${ex + gap + 9} ${ey - 17}l-15 8`} {...stroke} strokeWidth={5.5} />;
      mouth = <path d={`M${ex - 10} 22q10 -8 20 0`} {...stroke} />;
      break;
    case 'smug':
      eyes = (
        <>
          {eye(ex - gap, 4.2)}
          {eye(ex + gap, 4.2)}
        </>
      );
      brows = <path d={`M${ex - gap - 8} ${ey - 13}h14M${ex + gap - 8} ${ey - 18}l15 -4`} {...stroke} />;
      mouth = <path d={`M${ex - 10} 17q12 8 22 -4`} {...stroke} />;
      break;
    case 'think':
      eyes = (
        <>
          <ellipse cx={ex - gap + 2} cy={ey - 3} rx={5.6} ry={blink ? 1.2 : 7} fill={line} />
          <ellipse cx={ex + gap + 2} cy={ey - 3} rx={5.6} ry={blink ? 1.2 : 7} fill={line} />
        </>
      );
      brows = <path d={`M${ex + gap - 8} ${ey - 19}l15 -4`} {...stroke} />;
      mouth = <path d={`M${ex + 1} 19h12`} {...stroke} />;
      break;
    case 'sleepy':
      eyes = (
        <>
          <path d={`M${ex - gap - 7} ${ey}q7 7 14 0`} {...stroke} />
          <path d={`M${ex + gap - 7} ${ey}q7 7 14 0`} {...stroke} />
        </>
      );
      mouth = <ellipse cx={ex} cy={19} rx={4.5} ry={5.5} fill={line} />;
      break;
    case 'wink':
      eyes = (
        <>
          {eye(ex - gap)}
          <path d={`M${ex + gap - 7} ${ey}q7 -8 14 0`} {...stroke} />
        </>
      );
      mouth = <path d={`M${ex - 13} 14q13 15 26 0`} {...stroke} />;
      break;
    case 'love':
      eyes = (
        <>
          <path d={`M${ex - gap} ${ey + 8}c-14 -9 -10 -20 0 -12 10 -8 14 3 0 12z`} fill="#ff4d6d" />
          <path d={`M${ex + gap} ${ey + 8}c-14 -9 -10 -20 0 -12 10 -8 14 3 0 12z`} fill="#ff4d6d" />
        </>
      );
      mouth = <path d={`M${ex - 13} 15q13 15 26 0`} {...stroke} />;
      break;
    case 'dead':
      eyes = (
        <path
          d={`M${ex - gap - 6} ${ey - 6}l12 12m0 -12l-12 12M${ex + gap - 6} ${ey - 6}l12 12m0 -12l-12 12`}
          {...stroke}
        />
      );
      mouth = <path d={`M${ex - 9} 21h18`} {...stroke} />;
      break;
    case 'determined':
      brows = <path d={`M${ex - gap - 9} ${ey - 15}l15 5M${ex + gap + 9} ${ey - 15}l-15 5`} {...stroke} strokeWidth={5.5} />;
      mouth = <path d={`M${ex - 10} 18q10 5 20 0`} {...stroke} />;
      break;
    default:
      break;
  }
  return (
    <g>
      {brows}
      {eyes}
      {mouth}
      {extra}
    </g>
  );
};

const Hair: React.FC<{kind: string; color: string; r: number; back?: boolean}> = ({kind, color, r, back}) => {
  const o = {stroke: INK, strokeWidth: 4, strokeLinejoin: 'round' as const};
  if (back) {
    if (kind === 'ponytail')
      return <path d={`M${-r + 6} ${-r * 0.55}c-34 6 -42 44 -22 70 4 -22 12 -38 30 -48z`} fill={color} {...o} />;
    if (kind === 'long')
      return <path d={`M${-r - 4} ${-8}c-8 30 -6 62 4 84h${r * 1.5}V${-10}z`} fill={color} {...o} />;
    if (kind === 'bun') return <circle cx={-r * 0.55} cy={-r * 1.02} r={r * 0.36} fill={color} {...o} />;
    return null;
  }
  const capBase = `M${-r - 1} ${-6}A${r + 1} ${r + 1} 0 0 1 ${r + 1} ${-6}`;
  switch (kind) {
    case 'short':
      return <path d={`${capBase}q-${r * 0.5} -${r * 0.42} -${r + 1} -${r * 0.2}t-${r + 1} ${r * 0.2}z`} fill={color} {...o} />;
    case 'spiky':
      return (
        <path
          d={`M${-r - 2} ${-8}l-4 -24 18 8 2 -30 20 18 14 -28 12 26 22 -16 0 28 18 -6 -8 26q-${r * 0.5} -${r * 0.4} -${r + 1} -${r * 0.16}t-${r + 1} ${r * 0.14}z`}
          fill={color}
          {...o}
        />
      );
    case 'ponytail':
    case 'bun':
      return <path d={`${capBase}q-${r * 0.3} -${r * 0.52} -${r + 1} -${r * 0.4}t-${r + 1} ${r * 0.4}z`} fill={color} {...o} />;
    case 'bob':
      return (
        <path
          d={`M${-r - 5} ${r * 0.62}V${-6}A${r + 4} ${r + 4} 0 0 1 ${r + 4} ${-6}v${r * 0.2}q-${r * 0.5} -${r * 0.5} -${r} -${r * 0.34}q-${r * 0.5} ${r * 0.1} -${r * 0.62} ${r * 0.96}z`}
          fill={color}
          {...o}
        />
      );
    case 'long':
      return <path d={`${capBase}q-${r * 0.4} -${r * 0.5} -${r + 1} -${r * 0.34}q-${r * 0.6} ${r * 0.1} -${r + 1} ${r * 0.34}z`} fill={color} {...o} />;
    case 'curly':
      return (
        <g fill={color} {...o}>
          {[-0.9, -0.5, 0, 0.5, 0.9].map((k, i) => (
            <circle key={i} cx={k * r} cy={-r * (0.92 - Math.abs(k) * 0.5)} r={r * 0.34} />
          ))}
        </g>
      );
    case 'cap':
      return (
        <g>
          <path d={`${capBase}z`} fill={color} {...o} />
          <path d={`M${r * 0.3} ${-8}h${r * 1.25}`} stroke={color} strokeWidth={12} strokeLinecap="round" />
          <path d={`M${r * 0.3} ${-2}h${r * 1.25}`} stroke={INK} strokeWidth={4} strokeLinecap="round" />
        </g>
      );
    case 'beanie':
      return (
        <g>
          <path d={`M${-r - 2} ${-10}A${r + 2} ${r + 6} 0 0 1 ${r + 2} ${-10}z`} fill={color} {...o} />
          <rect x={-r - 5} y={-20} width={r * 2 + 10} height={15} rx={7} fill="#fff" {...o} />
          <circle cx={0} cy={-r - 8} r={9} fill="#fff" {...o} />
        </g>
      );
    case 'tophat':
      return (
        <g fill={color} {...o}>
          <rect x={-r * 0.62} y={-r * 2.05} width={r * 1.24} height={r * 1.15} rx={4} />
          <rect x={-r * 1.1} y={-r * 0.96} width={r * 2.2} height={12} rx={6} />
        </g>
      );
    default:
      return null;
  }
};

export const Character: React.FC<{state: ActorState; def: CharacterDef; seconds: number; idx?: number}> = ({
  state,
  def,
  seconds,
  idx = 0,
}) => {
  const j = state.joints;
  const line = def.line ?? INK;
  const skin = def.skin ?? '#ffffff';
  const top = def.top ?? 'none';
  const bottom = def.bottom ?? 'none';
  const topColor = def.topColor ?? '#ff7a3d';
  const bottomColor = def.bottomColor ?? '#2f4b7c';
  const shoesColor = def.shoesColor ?? '#ffffff';
  const acc = def.accessory ?? 'none';
  const accColor = def.accessoryColor ?? '#e63946';
  const limb = {stroke: line, strokeWidth: STROKE, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, fill: 'none'};
  const blink = (seconds * 0.9 + idx * 0.41) % 3.1 < 0.11;

  // torso frame
  const up = norm(sub(j.neck, j.hip));
  const side: Pt = {x: -up.y, y: up.x};
  const torsoPoly = (wTop: number, wBottom: number, below: number, above = 4) => {
    const a = along(j.shoulder, up, above);
    const b = along(j.hip, up, -below);
    const p = [along(a, side, -wTop), along(a, side, wTop), along(b, side, wBottom), along(b, side, -wBottom)];
    return p.map((q) => `${q.x.toFixed(1)},${q.y.toFixed(1)}`).join(' ');
  };
  const cloth = {stroke: INK, strokeWidth: 4, strokeLinejoin: 'round' as const};
  const longSleeve = ['hoodie', 'sweater', 'raincoat', 'suit', 'labcoat', 'jacket'].includes(top);
  const shortSleeve = ['tshirt', 'dress'].includes(top);
  const sleeveW = STROKE + 12;

  const arm = (elbow: Pt, hand: Pt, key: string) => (
    <g key={key}>
      <path d={`${seg(j.shoulder, elbow)} ${seg(elbow, hand)}`} {...limb} />
      {longSleeve ? (
        <>
          <path d={`${seg(j.shoulder, elbow)} ${seg(elbow, along(hand, norm(sub(elbow, hand)), 12))}`} stroke={INK} strokeWidth={sleeveW + 7} strokeLinecap="round" strokeLinejoin="round" fill="none" />
          <path d={`${seg(j.shoulder, elbow)} ${seg(elbow, along(hand, norm(sub(elbow, hand)), 12))}`} stroke={topColor} strokeWidth={sleeveW} strokeLinecap="round" strokeLinejoin="round" fill="none" />
        </>
      ) : null}
      {shortSleeve ? (
        <>
          <path d={seg(j.shoulder, along(j.shoulder, norm(sub(elbow, j.shoulder)), 34))} stroke={INK} strokeWidth={sleeveW + 7} strokeLinecap="round" fill="none" />
          <path d={seg(j.shoulder, along(j.shoulder, norm(sub(elbow, j.shoulder)), 34))} stroke={topColor} strokeWidth={sleeveW} strokeLinecap="round" fill="none" />
        </>
      ) : null}
    </g>
  );

  const leg = (knee: Pt, foot: Pt, key: string) => {
    const shinDir = norm(sub(foot, knee));
    const toe: Pt = {x: foot.x + 15, y: foot.y - 2};
    return (
      <g key={key}>
        <path d={`${seg(j.hip, knee)} ${seg(knee, foot)}`} {...limb} />
        {bottom === 'pants' ? (
          <>
            <path d={`${seg(j.hip, knee)} ${seg(knee, along(foot, shinDir, -14))}`} stroke={INK} strokeWidth={STROKE + 16} strokeLinecap="round" strokeLinejoin="round" fill="none" />
            <path d={`${seg(j.hip, knee)} ${seg(knee, along(foot, shinDir, -14))}`} stroke={bottomColor} strokeWidth={STROKE + 9} strokeLinecap="round" strokeLinejoin="round" fill="none" />
          </>
        ) : null}
        {bottom === 'shorts' ? (
          <>
            <path d={seg(j.hip, along(j.hip, norm(sub(knee, j.hip)), 40))} stroke={INK} strokeWidth={STROKE + 18} strokeLinecap="round" fill="none" />
            <path d={seg(j.hip, along(j.hip, norm(sub(knee, j.hip)), 40))} stroke={bottomColor} strokeWidth={STROKE + 11} strokeLinecap="round" fill="none" />
          </>
        ) : null}
        {def.shoes === 'boots' ? (
          <path d={`${seg(along(foot, shinDir, -30), foot)} ${seg(foot, toe)}`} stroke={INK} strokeWidth={STROKE + 15} strokeLinecap="round" strokeLinejoin="round" fill="none" />
        ) : null}
        {def.shoes === 'boots' ? (
          <path d={`${seg(along(foot, shinDir, -30), foot)} ${seg(foot, toe)}`} stroke={shoesColor} strokeWidth={STROKE + 8} strokeLinecap="round" strokeLinejoin="round" fill="none" />
        ) : null}
        {def.shoes === 'sneakers' ? (
          <>
            <path d={seg({x: foot.x - 6, y: foot.y - 1}, toe)} stroke={INK} strokeWidth={STROKE + 13} strokeLinecap="round" fill="none" />
            <path d={seg({x: foot.x - 6, y: foot.y - 1}, toe)} stroke={shoesColor} strokeWidth={STROKE + 6} strokeLinecap="round" fill="none" />
          </>
        ) : null}
      </g>
    );
  };

  const hem = top === 'raincoat' || top === 'labcoat' ? 44 : top === 'dress' ? 70 : top === 'jacket' || top === 'suit' ? 10 : 2;
  const wTop = top === 'tank' ? 22 : 30;
  const wBottom = top === 'dress' ? 58 : top === 'raincoat' || top === 'labcoat' ? 40 : 30;
  const heldW = (state.spec.holdSize ?? 84);

  return (
    <g transform={`translate(${state.x} ${state.groundY}) scale(${state.flip ? -state.scale : state.scale} ${state.scale})`}>
      {acc === 'cape' ? (
        <path d={`M${j.shoulder.x} ${j.shoulder.y}C${j.shoulder.x - 70} ${j.shoulder.y + 30} ${j.hip.x - 96} ${j.hip.y + 30} ${j.hip.x - 74} ${j.hip.y + 96}L${j.hip.x - 8} ${j.hip.y + 30}z`} fill={accColor} {...cloth} />
      ) : null}
      {acc === 'backpack' ? (
        <rect x={-34} y={0} width={34} height={74} rx={12} fill={accColor} {...cloth} transform={`translate(${j.shoulder.x - 8} ${j.shoulder.y + 4}) rotate(${-(state.joints.headAngle) * 0.3})`} />
      ) : null}
      {arm(j.elbowB, j.handB, 'armB')}
      {leg(j.kneeB, j.footB, 'legB')}
      <path d={seg(j.hip, j.neck)} {...limb} />
      {leg(j.kneeF, j.footF, 'legF')}
      {bottom === 'skirt' && top !== 'dress' ? <polygon points={(() => {
        const a = along(j.hip, up, 8);
        const b = along(j.hip, up, -46);
        return [along(a, side, -24), along(a, side, 24), along(b, side, 46), along(b, side, -46)].map((q) => `${q.x.toFixed(1)},${q.y.toFixed(1)}`).join(' ');
      })()} fill={bottomColor} {...cloth} /> : null}
      {top !== 'none' ? <polygon points={torsoPoly(wTop, wBottom, hem)} fill={topColor} {...cloth} /> : null}
      {top === 'hoodie' ? <path d={`M${j.shoulder.x - 20} ${j.shoulder.y + 62}h40v26h-40z`} fill="none" stroke={INK} strokeWidth={3} strokeLinejoin="round" opacity={0.55} /> : null}
      {top === 'suit' || top === 'labcoat' || top === 'jacket' ? (
        <path d={`${seg(along(j.shoulder, up, 4), along(j.hip, up, 30))}`} stroke={top === 'labcoat' ? '#9aa0ad' : '#ffffff'} strokeWidth={top === 'labcoat' ? 3 : 9} strokeLinecap="round" />
      ) : null}
      {acc === 'tie' ? <path d={`${seg(along(j.shoulder, up, 2), along(j.shoulder, up, -52))}`} stroke={accColor} strokeWidth={8} strokeLinecap="round" /> : null}
      {top === 'raincoat' ? <path d={seg(along(j.shoulder, up, 0), along(j.hip, up, -hem + 8))} stroke={INK} strokeWidth={3} opacity={0.5} /> : null}
      {acc === 'scarf' ? (
        <g>
          <path d={`M${j.neck.x - 4} ${j.neck.y + 6}l-26 44`} stroke={INK} strokeWidth={21} strokeLinecap="round" />
          <path d={`M${j.neck.x - 4} ${j.neck.y + 6}l-26 44`} stroke={accColor} strokeWidth={14} strokeLinecap="round" />
          <path d={`M${j.neck.x - 26} ${j.neck.y + 10}h52`} stroke={INK} strokeWidth={25} strokeLinecap="round" />
          <path d={`M${j.neck.x - 26} ${j.neck.y + 10}h52`} stroke={accColor} strokeWidth={18} strokeLinecap="round" />
        </g>
      ) : null}
      {/* head */}
      <g transform={`translate(${j.head.x} ${j.head.y}) rotate(${j.headAngle}) scale(${j.headR / HR})`}>
        {top === 'raincoat' ? <circle cx={-6} cy={-2} r={HR + 9} fill={topColor} stroke={INK} strokeWidth={4} /> : null}
        <Hair kind={def.hair ?? 'none'} color={def.hairColor ?? '#3a2a1e'} r={HR} back />
        <circle cx={0} cy={0} r={HR} fill={skin} stroke={line} strokeWidth={STROKE - 4} />
        <Face mood={state.mood} r={HR} blink={blink} line={line} />
        <Hair kind={def.hair ?? 'none'} color={def.hairColor ?? '#3a2a1e'} r={HR} />
        {acc === 'glasses' ? (
          <g fill="rgba(180,225,255,.45)" stroke={INK} strokeWidth={4}>
            <circle cx={-5} cy={-5} r={13} />
            <circle cx={27} cy={-5} r={13} />
            <path d="M8 -5h6M-18 -6l-22 -6" fill="none" />
          </g>
        ) : null}
        {acc === 'sunglasses' ? (
          <g fill={INK} stroke={INK} strokeWidth={4}>
            <rect x={-19} y={-15} width={26} height={18} rx={6} />
            <rect x={14} y={-15} width={26} height={18} rx={6} />
            <path d="M7 -8h8M-19 -8l-22 -5" fill="none" />
          </g>
        ) : null}
        {acc === 'headphones' ? (
          <g>
            <path d={`M${-HR + 4} -6A${HR + 5} ${HR + 5} 0 0 1 ${HR - 4} -6`} fill="none" stroke={INK} strokeWidth={8} />
            <rect x={-HR - 4} y={-16} width={18} height={34} rx={8} fill={accColor} stroke={INK} strokeWidth={4} />
          </g>
        ) : null}
        {acc === 'crown' ? <path d={`M-32 ${-HR + 6}l-4 -34 20 14 16 -24 16 24 20 -14 -4 34z`} fill="#ffcf3f" stroke={INK} strokeWidth={4} strokeLinejoin="round" /> : null}
        {acc === 'bow' ? <path d={`M-10 ${-HR + 2}l-22 -16v30zM-10 ${-HR + 2}l22 -16v30z`} fill={accColor} stroke={INK} strokeWidth={4} strokeLinejoin="round" /> : null}
      </g>
      {arm(j.elbowF, j.handF, 'armF')}
      {state.spec.hold ? (
        <g transform={state.flip ? `translate(${j.handF.x * 2} 0) scale(-1 1)` : undefined}>
          <Prop type={state.spec.hold} cx={j.handF.x} cy={j.handF.y} w={heldW} />
        </g>
      ) : null}
    </g>
  );
};
