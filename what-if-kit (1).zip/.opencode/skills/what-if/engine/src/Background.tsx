import React from 'react';
import {W, H, GROUND} from './layout';

type Pal = {
  sky: [string, string, string];
  wall: string;
  wall2: string;
  floor: string;
  floor2: string;
  ground: string;
  ground2: string;
  far: string;
  far2: string;
  light: string;
  ambient: string;
  orb: string;
  ink: string;
};

export const PALETTES: Record<string, Pal> = {
  day: {
    sky: ['#58b6f5', '#a8dcff', '#e9f7ff'],
    wall: '#f4e6cf',
    wall2: '#ead7b9',
    floor: '#d6b48a',
    floor2: '#c29a6c',
    ground: '#8fd07c',
    ground2: '#6fb65f',
    far: '#b7c9e8',
    far2: '#93a9d1',
    light: 'rgba(255,250,215,.42)',
    ambient: 'rgba(255,255,255,0)',
    orb: '#fff6c2',
    ink: '#1b1b22',
  },
  sunset: {
    sky: ['#6b3f8c', '#ff7a59', '#ffd08a'],
    wall: '#f1c69b',
    wall2: '#e2ad7e',
    floor: '#b77c56',
    floor2: '#9a6242',
    ground: '#c98f5a',
    ground2: '#a86f45',
    far: '#a2557a',
    far2: '#70396a',
    light: 'rgba(255,186,96,.55)',
    ambient: 'rgba(255,110,50,.10)',
    orb: '#fff0b0',
    ink: '#1b1b22',
  },
  night: {
    sky: ['#0b1030', '#1c2759', '#3b4a8c'],
    wall: '#3a4170',
    wall2: '#2f3560',
    floor: '#272c50',
    floor2: '#1d2140',
    ground: '#243a4f',
    ground2: '#1a2c3e',
    far: '#1b2350',
    far2: '#131a3f',
    light: 'rgba(150,185,255,.34)',
    ambient: 'rgba(16,24,80,.26)',
    orb: '#eef3ff',
    ink: '#0c0e1a',
  },
  dawn: {
    sky: ['#8aa7e8', '#ffb8c6', '#ffe6c2'],
    wall: '#f6dedd',
    wall2: '#ebcac9',
    floor: '#cfa59c',
    floor2: '#b88b83',
    ground: '#a9cf9a',
    ground2: '#8ab87e',
    far: '#c6a6cf',
    far2: '#a384b8',
    light: 'rgba(255,214,190,.48)',
    ambient: 'rgba(255,160,170,.08)',
    orb: '#fff3d6',
    ink: '#1b1b22',
  },
};

const FLOOR_Y = 770;
const HORIZON = 730;

const rnd = (seed: number) => {
  let s = seed;
  return () => {
    s = (s * 16807 + 11) % 2147483647;
    return (s % 10000) / 10000;
  };
};

const Sky: React.FC<{p: Pal; id: string; h?: number}> = ({p, id, h = H}) => (
  <>
    <defs>
      <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={p.sky[0]} />
        <stop offset="0.6" stopColor={p.sky[1]} />
        <stop offset="1" stopColor={p.sky[2]} />
      </linearGradient>
    </defs>
    <rect x={0} y={0} width={W} height={h} fill={`url(#${id})`} />
  </>
);

const Orb: React.FC<{p: Pal; time: string; x: number; y: number; r?: number}> = ({p, time, x, y, r = 70}) => (
  <g>
    <circle cx={x} cy={y} r={r * 2.6} fill={p.orb} opacity={0.14} />
    <circle cx={x} cy={y} r={r * 1.6} fill={p.orb} opacity={0.2} />
    <circle cx={x} cy={y} r={r} fill={p.orb} />
    {time === 'night' ? <circle cx={x + r * 0.42} cy={y - r * 0.28} r={r * 0.84} fill={p.sky[0]} /> : null}
  </g>
);

const Stars: React.FC<{count?: number; seed?: number; maxY?: number; seconds: number}> = ({count = 70, seed = 7, maxY = 640, seconds}) => {
  const r = rnd(seed);
  return (
    <g fill="#fff">
      {Array.from({length: count}).map((_, i) => {
        const x = r() * W;
        const y = r() * maxY;
        const s = 1.4 + r() * 2.6;
        const tw = 0.55 + 0.45 * Math.sin(seconds * (1 + r() * 2) + i);
        return <circle key={i} cx={x} cy={y} r={s} opacity={tw} />;
      })}
    </g>
  );
};

const Skyline: React.FC<{p: Pal; base: number; seed: number; color: string; lit?: boolean; minH?: number; maxH?: number}> = ({
  p,
  base,
  seed,
  color,
  lit,
  minH = 120,
  maxH = 380,
}) => {
  const r = rnd(seed);
  const out: React.ReactNode[] = [];
  let x = -20;
  let i = 0;
  while (x < W + 20) {
    const w = 90 + r() * 130;
    const h = minH + r() * (maxH - minH);
    out.push(<rect key={`b${i}`} x={x} y={base - h} width={w} height={h + 4} fill={color} />);
    if (lit) {
      for (let wy = base - h + 22; wy < base - 30; wy += 44) {
        for (let wx = x + 16; wx < x + w - 24; wx += 34) {
          if (r() > 0.45) out.push(<rect key={`w${i}-${wx}-${wy}`} x={wx} y={wy} width={16} height={22} rx={2} fill={p.orb} opacity={0.75} />);
        }
      }
    }
    x += w + 6;
    i++;
  }
  return <g>{out}</g>;
};

const Window: React.FC<{p: Pal; x: number; y: number; w: number; h: number; id: string; time: string; beam?: boolean}> = ({p, x, y, w, h, id, time, beam = true}) => (
  <g>
    {beam ? (
      <polygon points={`${x},${y} ${x + w},${y} ${x + w - 520},${H} ${x - 900},${H}`} fill={p.light} />
    ) : null}
    <defs>
      <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={p.sky[0]} />
        <stop offset="0.65" stopColor={p.sky[1]} />
        <stop offset="1" stopColor={p.sky[2]} />
      </linearGradient>
      <clipPath id={`${id}c`}>
        <rect x={x} y={y} width={w} height={h} rx={8} />
      </clipPath>
    </defs>
    <rect x={x} y={y} width={w} height={h} rx={8} fill={`url(#${id})`} />
    <g clipPath={`url(#${id}c)`}>
      <Orb p={p} time={time} x={x + w * 0.68} y={y + h * (time === 'day' ? 0.28 : 0.62)} r={34} />
      <rect x={x} y={y + h - 54} width={w} height={60} fill={p.far2} opacity={0.75} />
    </g>
    <rect x={x} y={y} width={w} height={h} rx={8} fill="none" stroke="#fff8ea" strokeWidth={16} />
    <path d={`M${x + w / 2} ${y}v${h}M${x} ${y + h / 2}h${w}`} stroke="#fff8ea" strokeWidth={10} />
    <rect x={x - 22} y={y + h + 2} width={w + 44} height={16} rx={6} fill="#fff8ea" />
  </g>
);

const Interior: React.FC<{p: Pal; children?: React.ReactNode; wall?: string; floor?: string}> = ({p, children, wall, floor}) => (
  <g>
    <rect x={0} y={0} width={W} height={FLOOR_Y} fill={wall ?? p.wall} />
    <rect x={0} y={FLOOR_Y - 150} width={W} height={150} fill={p.wall2} opacity={0.55} />
    <rect x={0} y={FLOOR_Y} width={W} height={H - FLOOR_Y} fill={floor ?? p.floor} />
    {[0.16, 0.42, 0.72].map((k, i) => (
      <rect key={i} x={0} y={FLOOR_Y + (H - FLOOR_Y) * k} width={W} height={3} fill={p.floor2} opacity={0.55} />
    ))}
    <rect x={0} y={FLOOR_Y - 14} width={W} height={18} fill="#fff8ea" opacity={0.85} />
    {children}
  </g>
);

const Ground: React.FC<{p: Pal; y?: number; color?: string; color2?: string}> = ({p, y = HORIZON, color, color2}) => (
  <g>
    <rect x={0} y={y} width={W} height={H - y} fill={color ?? p.ground} />
    <rect x={0} y={GROUND + 40} width={W} height={H - GROUND} fill={color2 ?? p.ground2} opacity={0.6} />
  </g>
);

type SceneProps = {p: Pal; time: string; seconds: number; uid: string};

const SCENES: Record<string, React.FC<SceneProps>> = {
  room: ({p, time, uid}) => (
    <Interior p={p}>
      <Window p={p} x={1240} y={170} w={380} h={330} id={`${uid}w`} time={time} />
      <rect x={220} y={210} width={220} height={160} rx={6} fill="#fff8ea" stroke={p.wall2} strokeWidth={10} />
      <path d="M240 350l60-70 50 44 40-34 30 60z" fill={p.far} />
      <ellipse cx={960} cy={GROUND + 70} rx={620} ry={70} fill={p.floor2} opacity={0.45} />
      <rect x={90} y={520} width={150} height={250} rx={10} fill={p.wall2} />
      <circle cx={165} cy={470} r={64} fill={p.ground2} opacity={0.9} />
    </Interior>
  ),
  bedroom: ({p, time, uid}) => (
    <Interior p={p}>
      <Window p={p} x={1300} y={160} w={340} h={320} id={`${uid}w`} time={time} />
      <rect x={110} y={600} width={620} height={130} rx={18} fill="#8ecae6" />
      <rect x={110} y={700} width={620} height={90} rx={10} fill={p.floor2} />
      <rect x={90} y={480} width={46} height={320} rx={10} fill={p.floor2} />
      <rect x={150} y={560} width={170} height={70} rx={30} fill="#fff" />
      <rect x={800} y={640} width={130} height={150} rx={8} fill={p.floor2} />
      <path d="M835 640v-70h60v70" fill="none" stroke={p.ink} strokeWidth={6} opacity={0.5} />
      <path d="M815 560h100l-20-60h-60z" fill={p.orb} />
    </Interior>
  ),
  classroom: ({p, time, uid}) => (
    <Interior p={p}>
      <Window p={p} x={1420} y={170} w={320} h={300} id={`${uid}w`} time={time} />
      <rect x={360} y={170} width={860} height={380} rx={10} fill="#2f5d50" stroke="#8a5a33" strokeWidth={18} />
      <path d="M430 270h300M430 340h420M430 410h220" stroke="#e8f3ee" strokeWidth={8} strokeLinecap="round" opacity={0.7} />
      <circle cx={190} cy={230} r={54} fill="#fff8ea" stroke={p.wall2} strokeWidth={10} />
      <path d="M190 230v-30M190 230l22 12" stroke={p.ink} strokeWidth={6} strokeLinecap="round" />
      {[160, 620, 1080, 1540].map((x) => (
        <g key={x} opacity={0.5}>
          <rect x={x} y={GROUND + 60} width={260} height={18} rx={6} fill={p.floor2} />
          <rect x={x + 20} y={GROUND + 78} width={12} height={110} fill={p.floor2} />
          <rect x={x + 228} y={GROUND + 78} width={12} height={110} fill={p.floor2} />
        </g>
      ))}
    </Interior>
  ),
  office: ({p, uid}) => (
    <Interior p={p} wall={p.wall2}>
      <defs>
        <linearGradient id={`${uid}o`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={p.sky[0]} />
          <stop offset="1" stopColor={p.sky[2]} />
        </linearGradient>
      </defs>
      <rect x={120} y={130} width={1680} height={470} rx={10} fill={`url(#${uid}o)`} />
      <g opacity={0.9}>
        <Skyline p={p} base={600} seed={31} color={p.far2} lit minH={90} maxH={330} />
      </g>
      <rect x={120} y={130} width={1680} height={470} rx={10} fill="none" stroke="#fff8ea" strokeWidth={16} />
      {[540, 960, 1380].map((x) => (
        <rect key={x} x={x - 6} y={130} width={12} height={470} fill="#fff8ea" />
      ))}
      <polygon points={`120,600 1800,600 1400,${H} -300,${H}`} fill={p.light} opacity={0.6} />
      <rect x={1620} y={620} width={70} height={150} rx={12} fill={p.floor2} />
      <circle cx={1655} cy={570} r={70} fill={p.ground2} />
    </Interior>
  ),
  kitchen: ({p, time, uid}) => (
    <Interior p={p}>
      <Window p={p} x={820} y={170} w={320} h={260} id={`${uid}w`} time={time} />
      <rect x={0} y={590} width={1320} height={190} fill="#fff8ea" />
      <rect x={0} y={570} width={1340} height={30} rx={6} fill={p.floor2} />
      {[60, 380, 700, 1020].map((x) => (
        <g key={x}>
          <rect x={x} y={620} width={280} height={140} rx={8} fill="none" stroke={p.wall2} strokeWidth={8} />
          <circle cx={x + 250} cy={690} r={8} fill={p.floor2} />
        </g>
      ))}
      <rect x={1440} y={250} width={300} height={530} rx={18} fill="#e9eef5" stroke={p.wall2} strokeWidth={8} />
      <path d="M1440 460h300M1480 330v70M1480 500v110" stroke={p.far2} strokeWidth={8} strokeLinecap="round" />
      <rect x={120} y={200} width={420} height={150} rx={10} fill={p.wall2} />
    </Interior>
  ),
  shop: ({p}) => (
    <Interior p={p}>
      {[150, 330, 510].map((y, row) => (
        <g key={y}>
          <rect x={120} y={y + 110} width={1680} height={18} rx={6} fill={p.floor2} />
          {Array.from({length: 17}).map((_, i) => {
            const colors = ['#ff6b6b', '#ffd166', '#06d6a0', '#4cc9f0', '#f78c6b', '#c77dff'];
            const h = 60 + ((i * 37 + row * 53) % 46);
            return <rect key={i} x={150 + i * 96} y={y + 110 - h} width={70} height={h} rx={8} fill={colors[(i + row * 2) % colors.length]} opacity={0.92} />;
          })}
        </g>
      ))}
      <rect x={1250} y={640} width={560} height={150} rx={10} fill={p.floor2} />
      <rect x={1230} y={620} width={600} height={28} rx={8} fill="#fff8ea" />
    </Interior>
  ),
  lab: ({p}) => (
    <Interior p={p} wall="#dfeaf2" floor="#b9c7d6">
      {Array.from({length: 13}).map((_, i) => (
        <rect key={i} x={i * 160} y={0} width={3} height={FLOOR_Y} fill="#c6d5e2" />
      ))}
      {[180, 390].map((y) => (
        <rect key={y} x={0} y={y} width={W} height={3} fill="#c6d5e2" />
      ))}
      <rect x={1180} y={170} width={560} height={330} rx={14} fill="#16243d" stroke="#8ea3bb" strokeWidth={12} />
      <path d="M1220 420l80-90 70 50 90-140 80 100 90-60 70 80" fill="none" stroke="#5cf2c8" strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" />
      <rect x={120} y={600} width={760} height={24} rx={8} fill="#8ea3bb" />
      {[190, 330, 470, 640].map((x, i) => (
        <g key={x}>
          <path d={`M${x} 600v-70l-34-60h112l-34 60v70z`} fill={['#ff8fab', '#7bdff2', '#b2f7ef', '#ffd166'][i]} stroke="#8ea3bb" strokeWidth={6} strokeLinejoin="round" opacity={0.9} />
        </g>
      ))}
      <rect x={140} y={624} width={20} height={150} fill="#8ea3bb" />
      <rect x={840} y={624} width={20} height={150} fill="#8ea3bb" />
    </Interior>
  ),
  stage: ({p}) => (
    <g>
      <rect x={0} y={0} width={W} height={H} fill="#2a1020" />
      <polygon points={`760,0 1160,0 1500,${GROUND + 60} 420,${GROUND + 60}`} fill="rgba(255,240,190,.2)" />
      <rect x={0} y={FLOOR_Y} width={W} height={H - FLOOR_Y} fill="#7a4a2b" />
      <ellipse cx={960} cy={GROUND + 40} rx={560} ry={70} fill="rgba(255,240,190,.28)" />
      {[0, 1].map((s) => (
        <g key={s} transform={s ? `translate(${W} 0) scale(-1 1)` : undefined}>
          <path d={`M0 0h330c-20 260-90 520-70 ${FLOOR_Y}H0z`} fill="#b3202e" />
          <path d={`M90 0c-10 300-30 560-10 ${FLOOR_Y}M190 0c-10 300-40 560-20 ${FLOOR_Y}`} stroke="#7d1420" strokeWidth={10} fill="none" />
        </g>
      ))}
      <rect x={0} y={0} width={W} height={90} fill="#8a1823" />
      <rect x={0} y={0} width={W} height={H} fill={p.ambient} />
    </g>
  ),
  street: ({p, time, uid, seconds}) => (
    <g>
      <Sky p={p} id={`${uid}s`} />
      {time === 'night' ? <Stars seconds={seconds} maxY={420} /> : null}
      <Orb p={p} time={time} x={1500} y={time === 'day' ? 180 : 430} />
      <Skyline p={p} base={HORIZON} seed={12} color={p.far} minH={160} maxH={470} />
      <Skyline p={p} base={HORIZON} seed={5} color={p.far2} lit minH={80} maxH={300} />
      <rect x={0} y={HORIZON} width={W} height={H - HORIZON} fill={time === 'night' ? '#2b3050' : '#b9b3ad'} />
      <rect x={0} y={GROUND + 46} width={W} height={H - GROUND} fill={time === 'night' ? '#1b1e36' : '#5d5f6b'} />
      {[100, 520, 940, 1360, 1780].map((x) => (
        <rect key={x} x={x} y={GROUND + 108} width={170} height={12} rx={6} fill="#fff" opacity={0.7} />
      ))}
      <rect x={330} y={300} width={16} height={460} fill={p.ink} opacity={0.75} />
      <path d="M338 300h90" stroke={p.ink} strokeWidth={14} strokeLinecap="round" opacity={0.75} />
      <circle cx={430} cy={318} r={26} fill={p.orb} />
      {time !== 'day' ? <polygon points={`404,330 456,330 640,${GROUND + 40} 220,${GROUND + 40}`} fill={p.light} opacity={0.6} /> : null}
    </g>
  ),
  rooftop: ({p, time, uid, seconds}) => (
    <g>
      <Sky p={p} id={`${uid}s`} />
      {time === 'night' ? <Stars seconds={seconds} /> : null}
      <Orb p={p} time={time} x={420} y={time === 'day' ? 200 : 520} r={90} />
      <Skyline p={p} base={830} seed={21} color={p.far} minH={120} maxH={360} />
      <Skyline p={p} base={830} seed={9} color={p.far2} lit minH={60} maxH={220} />
      <rect x={0} y={800} width={W} height={H - 800} fill={time === 'night' ? '#32385f' : '#8d8794'} />
      <rect x={0} y={780} width={W} height={34} fill={time === 'night' ? '#454c7c' : '#a9a3b0'} />
      <rect x={1500} y={600} width={150} height={190} rx={8} fill={p.far2} />
      <rect x={1560} y={520} width={12} height={90} fill={p.far2} />
    </g>
  ),
  park: ({p, time, uid, seconds}) => (
    <g>
      <Sky p={p} id={`${uid}s`} />
      {time === 'night' ? <Stars seconds={seconds} maxY={430} /> : null}
      <Orb p={p} time={time} x={1560} y={time === 'day' ? 170 : 470} />
      <path d={`M0 ${HORIZON}C300 560 620 600 900 ${HORIZON - 40}S1560 560 ${W} ${HORIZON - 60}V${H}H0z`} fill={p.far} />
      <Ground p={p} />
      <path d={`M700 ${H}C820 920 980 840 1040 ${HORIZON}h70C1120 860 1160 940 1300 ${H}z`} fill="#f1dcb0" opacity={0.75} />
      {[
        [150, 1.25],
        [470, 0.8],
        [1420, 1],
        [1750, 1.35],
      ].map(([x, s], i) => (
        <g key={i} transform={`translate(${x} ${HORIZON + 30}) scale(${s})`}>
          <rect x={-14} y={-150} width={28} height={160} fill="#7a4f2c" />
          <circle cx={0} cy={-220} r={110} fill={p.ground2} />
          <circle cx={-70} cy={-170} r={70} fill={p.ground2} />
          <circle cx={74} cy={-176} r={76} fill={p.ground2} />
        </g>
      ))}
    </g>
  ),
  forest: ({p, time, uid, seconds}) => {
    const r = rnd(44);
    return (
      <g>
        <Sky p={p} id={`${uid}s`} />
        {time === 'night' ? <Stars seconds={seconds} maxY={300} /> : null}
        {Array.from({length: 16}).map((_, i) => {
          const x = i * 130 - 30 + r() * 50;
          const h = 420 + r() * 300;
          return <polygon key={i} points={`${x - 110},${HORIZON + 20} ${x},${HORIZON - h} ${x + 110},${HORIZON + 20}`} fill={i % 2 ? p.far : p.far2} />;
        })}
        <Ground p={p} color={p.ground2} />
        {[90, 620, 1300, 1790].map((x, i) => (
          <g key={i}>
            <rect x={x - 26} y={120} width={52} height={GROUND - 60} fill="#4a3220" />
            <polygon points={`${x - 220},420 ${x},-60 ${x + 220},420`} fill={p.ground2} opacity={0.96} />
          </g>
        ))}
        <polygon points={`700,0 1120,0 1500,${H} 380,${H}`} fill={p.light} opacity={0.45} />
      </g>
    );
  },
  beach: ({p, time, uid, seconds}) => (
    <g>
      <Sky p={p} id={`${uid}s`} />
      {time === 'night' ? <Stars seconds={seconds} maxY={400} /> : null}
      <Orb p={p} time={time} x={960} y={time === 'day' ? 190 : 560} r={96} />
      <rect x={0} y={620} width={W} height={200} fill={time === 'night' ? '#1c3a6b' : '#3fa7d6'} />
      {[650, 700, 750].map((y, i) => (
        <path key={y} d={`M${-80 + Math.sin(seconds * 1.2 + i) * 40} ${y}q60 -16 120 0t120 0 120 0 120 0 120 0 120 0 120 0 120 0 120 0 120 0 120 0 120 0 120 0 120 0 120 0 120 0 120 0`} fill="none" stroke="#fff" strokeWidth={5} opacity={0.4} />
      ))}
      <path d={`M0 800q480 -50 960 -10t960 -20V${H}H0z`} fill="#f2d7a0" />
      <rect x={0} y={GROUND + 60} width={W} height={H} fill="#e0bf82" opacity={0.6} />
    </g>
  ),
  space: ({p, seconds}) => (
    <g>
      <rect x={0} y={0} width={W} height={H} fill="#070a1c" />
      <Stars count={150} seed={3} maxY={H} seconds={seconds} />
      <circle cx={1500} cy={260} r={150} fill="#4f9dde" />
      <path d="M1400 200c50-30 110 0 100 50s-70 40-90 90M1560 160c50 10 90 50 100 110-50 10-90-20-100-110z" fill="#62c370" />
      <circle cx={1500} cy={260} r={150} fill="none" stroke="#bfe6ff" strokeWidth={10} opacity={0.35} />
      <path d={`M0 ${GROUND - 40}q480 -70 960 -30t960 -20V${H}H0z`} fill="#8c8fa3" />
      {[260, 760, 1320, 1700].map((x, i) => (
        <ellipse key={x} cx={x} cy={GROUND + 70 + (i % 2) * 40} rx={90 - i * 10} ry={20} fill="#6d7087" />
      ))}
      <rect x={0} y={0} width={W} height={H} fill={p.ambient} opacity={0.4} />
    </g>
  ),
  void: ({p, time, uid}) => {
    const base = time === 'night' ? '#11142b' : time === 'sunset' ? '#ff8f5a' : time === 'dawn' ? '#ffc9d2' : '#ffe9bf';
    const glow = time === 'night' ? 'rgba(120,150,255,.38)' : 'rgba(255,255,255,.6)';
    return (
      <g>
        <defs>
          <radialGradient id={`${uid}v`} cx="0.5" cy="0.55" r="0.65">
            <stop offset="0" stopColor={glow} />
            <stop offset="1" stopColor="rgba(0,0,0,0)" />
          </radialGradient>
        </defs>
        <rect x={0} y={0} width={W} height={H} fill={base} />
        <rect x={0} y={0} width={W} height={H} fill={`url(#${uid}v)`} />
        <ellipse cx={960} cy={GROUND + 30} rx={700} ry={56} fill={p.ink} opacity={0.14} />
      </g>
    );
  },
  mountain: ({p, time, uid, seconds}) => (
    <g>
      <Sky p={p} id={`${uid}s`} />
      {time === 'night' ? <Stars seconds={seconds} maxY={500} /> : null}
      <Orb p={p} time={time} x={380} y={time === 'day' ? 180 : 420} />
      <polygon points={`-100,${HORIZON + 40} 500,220 900,560 1300,160 2100,${HORIZON + 40}`} fill={p.far} />
      <polygon points="500,220 420,330 470,320 520,360 580,300 610,330" fill="#fff" opacity={0.9} />
      <polygon points="1300,160 1200,300 1260,290 1310,340 1380,280 1420,320" fill="#fff" opacity={0.9} />
      <polygon points={`200,${HORIZON + 40} 900,470 1700,${HORIZON + 40}`} fill={p.far2} />
      <path d={`M0 ${HORIZON + 20}h1250l90 60H${W}V${H}H0z`} fill={time === 'night' ? '#39406b' : '#9a8f86'} />
      <rect x={0} y={GROUND + 50} width={W} height={H} fill={p.ink} opacity={0.12} />
    </g>
  ),
};

export const BG_NAMES = Object.keys(SCENES);

export const Background: React.FC<{bg?: string; time?: string; seconds: number; uid: string}> = ({bg = 'void', time = 'sunset', seconds, uid}) => {
  const p = PALETTES[time] ?? PALETTES.sunset;
  const Scene = SCENES[bg] ?? SCENES.void;
  return (
    <g>
      <Scene p={p} time={time} seconds={seconds} uid={uid} />
      <rect x={0} y={0} width={W} height={H} fill={p.ambient} />
    </g>
  );
};
