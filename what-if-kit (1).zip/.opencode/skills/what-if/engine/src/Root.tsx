import React from 'react';
import {AbsoluteFill, Composition, Sequence, useCurrentFrame, useVideoConfig} from 'remotion';
import {Episode, H, W, actorAt, mergeTiming} from './layout';
import {FONT, Shot} from './Shot';
import {Character, CharacterDef} from './Character';
import defaults from './characters.default.json';

export const FPS = 30;
const TAIL = 0.7; // seconds of hold after the last word

type Timing = {duration?: number; shots?: {start: number; end: number}[]; words?: {w: string; start: number; end: number}[]} | null;
export type Props = {episode: Episode; timing: Timing; characters: Record<string, CharacterDef>};

const demo: Props = {
  episode: {
    slug: 'demo',
    title: 'What If You Could See One Minute Ahead?',
    hero: 'max',
    shots: [
      {beat: 'hook', say: 'What if you could see one minute into the future?', bg: 'room', time: 'sunset', camera: {size: 'medium', move: 'push'}, actors: [{who: 'max', x: 50, pose: 'think', mood: 'think'}], text: {value: 'What if?', style: 'impact'}},
    ],
  },
  timing: null,
  characters: defaults as Record<string, CharacterDef>,
};

const cast = (p: Props) => ({...(defaults as Record<string, CharacterDef>), ...(p.characters ?? {})});

const Subtitles: React.FC<{timing: Timing}> = ({timing}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const now = frame / fps;
  const words = timing?.words ?? [];
  if (!words.length) return null;
  const idx = words.findIndex((w) => now >= w.start && now < w.end + 0.12);
  if (idx < 0) return null;
  const start = Math.floor(idx / 3) * 3;
  const chunk = words.slice(start, start + 3);
  return (
    <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 150}}>
      <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 64, WebkitTextStroke: '9px #1b1b22', paintOrder: 'stroke fill', display: 'flex', gap: 18}}>
        {chunk.map((w, i) => (
          <span key={i} style={{color: start + i === idx ? '#ffdd33' : '#ffffff'}}>
            {w.w}
          </span>
        ))}
      </div>
    </AbsoluteFill>
  );
};

const EpisodeComp: React.FC<Props> = (p) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const slots = mergeTiming(p.episode, p.timing, fps);
  const characters = cast(p);
  return (
    <AbsoluteFill style={{background: '#000'}}>
      {p.episode.shots.map((shot, i) => {
        const from = slots[i].from;
        const next = i + 1 < slots.length ? slots[i + 1].from : durationInFrames;
        const frames = Math.max(1, next - from);
        return (
          <Sequence key={i} from={from} durationInFrames={frames} layout="none">
            <Shot shot={shot} frame={frame - from} frames={frames} fps={fps} seconds={frame / fps} hero={p.episode.hero} characters={characters} uid={`s${i}`} punch={i > 0} />
          </Sequence>
        );
      })}
      {p.episode.subtitles === 'words' ? <Subtitles timing={p.timing} /> : null}
    </AbsoluteFill>
  );
};

// One frame per shot: frame N shows shot N at its most readable moment.
const BoardComp: React.FC<Props> = (p) => {
  const frame = useCurrentFrame();
  const slots = mergeTiming(p.episode, p.timing, FPS);
  const i = Math.min(frame, p.episode.shots.length - 1);
  const frames = slots[i].frames;
  const at = Math.round(frames * 0.62);
  return <Shot shot={p.episode.shots[i]} frame={at} frames={frames} fps={FPS} seconds={i * 1.37 + at / FPS} hero={p.episode.hero} characters={cast(p)} uid={`b${i}`} punch={false} />;
};

const SheetComp: React.FC<Props> = (p) => {
  const characters = cast(p);
  const ids = Object.keys(characters);
  const perRow = Math.min(6, Math.max(4, Math.ceil(ids.length / Math.ceil(ids.length / 6))));
  const rows = Math.ceil(ids.length / perRow);
  const rowH = (H - 150) / rows;
  const scale = Math.min(1.25, (rowH - 110) / 380);
  return (
    <AbsoluteFill style={{background: 'linear-gradient(#ffe2b8,#ffb98a)'}}>
      <div style={{position: 'absolute', top: 34, left: 0, right: 0, textAlign: 'center', fontFamily: FONT, fontWeight: 900, fontSize: 58, color: '#1b1b22'}}>CHARACTER SHEET</div>
      <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H}>
        {ids.map((id, i) => {
          const row = Math.floor(i / perRow);
          const inRow = Math.min(perRow, ids.length - row * perRow);
          const col = i % perRow;
          const x = ((col + 0.5) / inRow) * 100;
          const groundY = 150 + rowH * (row + 1) - 96;
          const st = actorAt({who: id, x, scale, pose: i % 3 === 1 ? 'hands-hips' : i % 3 === 2 ? 'wave' : 'relaxed', mood: 'happy'}, 0.3, 0.4, i);
          st.groundY = groundY;
          return (
            <g key={id}>
              <ellipse cx={st.x} cy={groundY + 6} rx={90 * scale} ry={14 * scale} fill="#1b1b22" opacity={0.18} />
              <Character state={st} def={characters[id]} seconds={0.4} idx={i} />
              <text x={st.x} y={groundY + 62} textAnchor="middle" fontFamily={FONT} fontWeight={900} fontSize={38} fill="#1b1b22">
                {id}
              </text>
            </g>
          );
        })}
      </svg>
    </AbsoluteFill>
  );
};

export const Root: React.FC = () => (
  <>
    <Composition
      id="Episode"
      component={EpisodeComp}
      width={W}
      height={H}
      fps={FPS}
      durationInFrames={60}
      defaultProps={demo}
      calculateMetadata={({props}) => {
        const slots = mergeTiming(props.episode, props.timing, FPS);
        const last = slots[slots.length - 1];
        const speechEnd = last.from + last.frames;
        const total = Math.max(speechEnd, Math.round((props.timing?.duration ?? 0) * FPS)) + Math.round(TAIL * FPS);
        return {durationInFrames: total};
      }}
    />
    <Composition id="Board" component={BoardComp} width={W} height={H} fps={FPS} durationInFrames={1} defaultProps={demo} calculateMetadata={({props}) => ({durationInFrames: props.episode.shots.length})} />
    <Composition id="Sheet" component={SheetComp} width={W} height={H} fps={FPS} durationInFrames={1} defaultProps={demo} />
  </>
);
