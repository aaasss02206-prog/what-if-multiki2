import React from 'react';
import {registerPropSize} from './layout';

// Every prop is drawn in a 100 x H box (H = 100 * aspect) with the same ink
// outline as the characters, so everything looks like one hand drew it.
const INK = '#1b1b22';
const sw = 5;
const base = {stroke: INK, strokeWidth: sw, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

type Draw = (text?: string) => React.ReactNode;
type Def = {h: number; draw: Draw};

const D: Record<string, Def> = {
  ball: {
    h: 100,
    draw: () => (
      <>
        <circle cx={50} cy={50} r={45} fill="#ff8a3d" {...base} />
        <path d="M5 50h90M50 5v90M20 16c16 20 16 48 0 68M80 16c-16 20-16 48 0 68" fill="none" {...base} strokeWidth={3.5} />
      </>
    ),
  },
  phone: {
    h: 170,
    draw: () => (
      <>
        <rect x={10} y={5} width={80} height={160} rx={14} fill="#2b2d3a" {...base} />
        <rect x={19} y={20} width={62} height={118} rx={5} fill="#8fd3ff" />
        <circle cx={50} cy={151} r={5} fill="#8fd3ff" />
      </>
    ),
  },
  book: {
    h: 76,
    draw: () => (
      <>
        <path d="M50 14C36 4 18 4 5 10v56c13-6 31-6 45 4 14-10 32-10 45-4V10C82 4 64 4 50 14z" fill="#fff6e0" {...base} />
        <path d="M50 14v56M16 26h22M16 40h22M62 26h22M62 40h22" fill="none" {...base} strokeWidth={3} />
      </>
    ),
  },
  coin: {
    h: 100,
    draw: () => (
      <>
        <circle cx={50} cy={50} r={45} fill="#ffcf3f" {...base} />
        <circle cx={50} cy={50} r={32} fill="none" stroke="#c98a00" strokeWidth={4} />
        <text x={50} y={68} textAnchor="middle" fontSize={50} fontWeight={900} fill="#c98a00" fontFamily="Arial, sans-serif">
          $
        </text>
      </>
    ),
  },
  cash: {
    h: 62,
    draw: () => (
      <>
        <rect x={12} y={4} width={84} height={44} rx={5} fill="#57b56a" {...base} />
        <rect x={4} y={14} width={84} height={44} rx={5} fill="#7bd88a" {...base} />
        <circle cx={46} cy={36} r={12} fill="none" stroke="#2f7f43" strokeWidth={4} />
      </>
    ),
  },
  clock: {
    h: 100,
    draw: () => (
      <>
        <circle cx={50} cy={50} r={45} fill="#fffdf5" {...base} />
        <path d="M50 22v28l18 12" fill="none" {...base} />
        <circle cx={50} cy={50} r={4} fill={INK} />
      </>
    ),
  },
  hourglass: {
    h: 140,
    draw: () => (
      <>
        <path d="M15 8h70M15 132h70" {...base} strokeWidth={8} />
        <path d="M22 10c0 34 22 44 28 60 6-16 28-26 28-60zM22 130c0-34 22-44 28-60 6 16 28 26 28 60z" fill="#eaf6ff" {...base} />
        <path d="M34 122c2-16 12-22 16-30 4 8 14 14 16 30z" fill="#ffb84d" />
        <path d="M40 30h20l-10 16z" fill="#ffb84d" />
      </>
    ),
  },
  laptop: {
    h: 70,
    draw: () => (
      <>
        <rect x={16} y={4} width={68} height={46} rx={5} fill="#2b2d3a" {...base} />
        <rect x={23} y={11} width={54} height={32} fill="#8fd3ff" />
        <path d="M4 56h92l-6 10H10z" fill="#c9ccd6" {...base} />
      </>
    ),
  },
  cup: {
    h: 92,
    draw: () => (
      <>
        <path d="M70 34h10c14 0 14 26 0 26H68" fill="none" {...base} />
        <path d="M14 24h60l-6 56c-1 6-5 8-10 8H30c-5 0-9-2-10-8z" fill="#fff" {...base} />
        <path d="M32 14c-6-6 6-8 0-14M50 14c-6-6 6-8 0-14" fill="none" {...base} strokeWidth={3.5} />
      </>
    ),
  },
  box: {
    h: 86,
    draw: () => (
      <>
        <rect x={6} y={18} width={88} height={64} rx={4} fill="#d9a066" {...base} />
        <path d="M6 18l12-14h64l12 14M50 18v22" fill="#e9b97f" {...base} />
      </>
    ),
  },
  gift: {
    h: 100,
    draw: () => (
      <>
        <rect x={10} y={38} width={80} height={56} rx={4} fill="#ff5d73" {...base} />
        <rect x={5} y={24} width={90} height={20} rx={4} fill="#ff7d90" {...base} />
        <path d="M50 24v70M50 24c-22-26-40-2-16 0M50 24c22-26 40-2 16 0" fill="none" stroke="#ffd23f" strokeWidth={7} strokeLinecap="round" />
      </>
    ),
  },
  bulb: {
    h: 130,
    draw: () => (
      <>
        <path d="M50 6C24 6 10 26 10 46c0 18 12 28 18 40v10h44V86c6-12 18-22 18-40C90 26 76 6 50 6z" fill="#ffe66b" {...base} />
        <path d="M32 104h36M36 116h28" {...base} />
        <path d="M38 62l12-14 12 14" fill="none" {...base} strokeWidth={3.5} />
      </>
    ),
  },
  key: {
    h: 46,
    draw: () => (
      <>
        <circle cx={22} cy={23} r={17} fill="#ffcf3f" {...base} />
        <circle cx={22} cy={23} r={5} fill="#fff" stroke={INK} strokeWidth={3} />
        <path d="M39 23h56M78 23v14M90 23v10" fill="none" {...base} strokeWidth={7} />
      </>
    ),
  },
  umbrella: {
    h: 110,
    draw: () => (
      <>
        <path d="M50 14C20 14 6 36 5 52c10-8 20-8 30 0 10-8 20-8 30 0 10-8 20-8 30 0-1-16-15-38-45-38z" fill="#5aa9ff" {...base} />
        <path d="M50 14V6M50 50v44c0 12-16 12-16 0" fill="none" {...base} />
      </>
    ),
  },
  heart: {
    h: 92,
    draw: () => (
      <path d="M50 88C10 60 2 40 8 24 16 4 40 4 50 22 60 4 84 4 92 24c6 16-2 36-42 64z" fill="#ff4d6d" {...base} />
    ),
  },
  star: {
    h: 96,
    draw: () => (
      <path d="M50 4l14 30 32 4-24 22 6 32-28-16-28 16 6-32L4 38l32-4z" fill="#ffd23f" {...base} />
    ),
  },
  trophy: {
    h: 118,
    draw: () => (
      <>
        <path d="M24 12H6c0 22 8 34 22 36M76 12h18c0 22-8 34-22 36" fill="none" {...base} />
        <path d="M22 6h56v30c0 22-12 34-28 34S22 58 22 36z" fill="#ffcf3f" {...base} />
        <path d="M50 70v20M30 110h40l-4-20H34z" fill="#c98a00" {...base} />
      </>
    ),
  },
  apple: {
    h: 108,
    draw: () => (
      <>
        <path d="M50 30C36 16 8 22 8 54c0 26 18 48 30 48 6 0 8-4 12-4s6 4 12 4c12 0 30-22 30-48 0-32-28-38-42-24z" fill="#ff5a4f" {...base} />
        <path d="M50 30c0-12 4-20 12-26" fill="none" {...base} />
        <path d="M58 12c10-8 20-6 26 0-8 8-18 8-26 0z" fill="#6cc24a" {...base} strokeWidth={3.5} />
      </>
    ),
  },
  paper: {
    h: 128,
    draw: (text) => (
      <>
        <path d="M8 4h60l24 24v96H8z" fill="#fffdf5" {...base} />
        <path d="M68 4v24h24" fill="#e8e2d0" {...base} />
        {text ? (
          <text x={50} y={86} textAnchor="middle" fontSize={44} fontWeight={900} fill="#e5383b" fontFamily="Arial, sans-serif">
            {text.slice(0, 3)}
          </text>
        ) : (
          <path d="M22 48h56M22 66h56M22 84h56M22 102h34" fill="none" stroke="#9aa0ad" strokeWidth={4} strokeLinecap="round" />
        )}
      </>
    ),
  },
  bag: {
    h: 108,
    draw: () => (
      <>
        <path d="M34 28c-8-8-8-16 0-22h32c8 6 8 14 0 22" fill="#b98b52" {...base} />
        <path d="M34 28h32c20 18 28 40 28 54 0 14-10 22-22 22H28C16 104 6 96 6 82c0-14 8-36 28-54z" fill="#d9a066" {...base} />
        <text x={50} y={86} textAnchor="middle" fontSize={46} fontWeight={900} fill="#7a5527" fontFamily="Arial, sans-serif">
          $
        </text>
      </>
    ),
  },
  lightning: {
    h: 150,
    draw: () => <path d="M62 4L10 84h34L30 146l60-88H56z" fill="#ffe14d" {...base} />,
  },
  fire: {
    h: 126,
    draw: () => (
      <>
        <path d="M50 4c6 26 38 36 38 72 0 26-18 46-38 46S12 102 12 76c0-18 10-26 16-38 4 10 8 14 14 14-4-18 0-36 8-48z" fill="#ff7b2e" {...base} />
        <path d="M50 62c4 12 18 18 18 34 0 12-8 20-18 20s-18-8-18-20c0-10 6-14 10-20 2 4 4 6 6 6-2-8 0-14 2-20z" fill="#ffd23f" />
      </>
    ),
  },
  question: {
    h: 140,
    draw: () => (
      <text x={50} y={122} textAnchor="middle" fontSize={150} fontWeight={900} fill="#ffd23f" stroke={INK} strokeWidth={6} paintOrder="stroke" fontFamily="Arial, sans-serif">
        ?
      </text>
    ),
  },
  exclaim: {
    h: 140,
    draw: () => (
      <text x={50} y={122} textAnchor="middle" fontSize={150} fontWeight={900} fill="#ff4d4d" stroke={INK} strokeWidth={6} paintOrder="stroke" fontFamily="Arial, sans-serif">
        !
      </text>
    ),
  },
  zzz: {
    h: 90,
    draw: () => (
      <text x={50} y={72} textAnchor="middle" fontSize={64} fontWeight={900} fill="#cfe6ff" stroke={INK} strokeWidth={5} paintOrder="stroke" fontFamily="Arial, sans-serif">
        Zzz
      </text>
    ),
  },
  brain: {
    h: 84,
    draw: () => (
      <>
        <path d="M50 10c-8-8-24-6-28 4-12 0-18 12-12 22-8 8-4 22 8 24 2 12 20 16 32 8 12 8 30 4 32-8 12-2 16-16 8-24 6-10 0-22-12-22-4-10-20-12-28-4z" fill="#ff9fb8" {...base} />
        <path d="M50 10v58M30 30c8 0 10 8 4 14M70 30c-8 0-10 8-4 14M26 54c8-4 14 0 14 6M74 54c-8-4-14 0-14 6" fill="none" {...base} strokeWidth={3.5} />
      </>
    ),
  },
  snail: {
    h: 70,
    draw: () => (
      <>
        <path d="M6 62h78c10 0 12-10 6-20l-6-10" fill="#ffe0a3" {...base} />
        <path d="M84 32l4-18M78 34l-6-16" fill="none" {...base} strokeWidth={4} />
        <circle cx={40} cy={36} r={28} fill="#c98b5a" {...base} />
        <path d="M40 36c0-8 12-8 12 2s-18 12-22 0 10-26 24-20" fill="none" {...base} strokeWidth={3.5} />
      </>
    ),
  },
  car: {
    h: 46,
    draw: () => (
      <>
        <path d="M4 34V24c0-4 3-6 8-6l12-12c2-2 4-3 8-3h28c4 0 6 1 8 3l10 12h10c6 0 8 3 8 8v8z" fill="#ff5d5d" {...base} strokeWidth={3.5} />
        <path d="M30 18l8-10h10v10zM54 18V8h10l8 10z" fill="#bfe6ff" stroke={INK} strokeWidth={2.5} />
        <circle cx={26} cy={36} r={8} fill="#2b2d3a" stroke={INK} strokeWidth={3} />
        <circle cx={76} cy={36} r={8} fill="#2b2d3a" stroke={INK} strokeWidth={3} />
      </>
    ),
  },
  rocket: {
    h: 170,
    draw: () => (
      <>
        <path d="M50 4C28 30 24 70 28 116h44c4-46 0-86-22-112z" fill="#f4f6fb" {...base} />
        <circle cx={50} cy={62} r={12} fill="#8fd3ff" {...base} strokeWidth={4} />
        <path d="M28 96L8 126h22zM72 96l20 30H70z" fill="#ff5d5d" {...base} />
        <path d="M38 118c0 22 6 34 12 48 6-14 12-26 12-48z" fill="#ffb02e" {...base} strokeWidth={4} />
      </>
    ),
  },
  bed: {
    h: 46,
    draw: () => (
      <>
        <path d="M4 6v38M96 22v22" {...base} />
        <rect x={4} y={24} width={92} height={12} rx={3} fill="#8ecae6" {...base} strokeWidth={4} />
        <rect x={8} y={14} width={22} height={10} rx={5} fill="#fff" {...base} strokeWidth={3.5} />
      </>
    ),
  },
  desk: {
    h: 52,
    draw: () => (
      <>
        <rect x={2} y={4} width={96} height={9} rx={3} fill="#b9814f" {...base} strokeWidth={4} />
        <path d="M12 13v37M88 13v37" {...base} />
      </>
    ),
  },
  chair: {
    h: 130,
    draw: () => (
      <>
        <path d="M22 6v118M22 70h60v54" fill="none" {...base} strokeWidth={8} />
        <rect x={18} y={64} width={68} height={12} rx={5} fill="#b9814f" {...base} strokeWidth={4} />
      </>
    ),
  },
  door: {
    h: 190,
    draw: () => (
      <>
        <rect x={6} y={4} width={88} height={184} rx={4} fill="#a8683a" {...base} />
        <rect x={18} y={16} width={64} height={70} rx={3} fill="none" stroke="#7a4721" strokeWidth={4} />
        <rect x={18} y={100} width={64} height={74} rx={3} fill="none" stroke="#7a4721" strokeWidth={4} />
        <circle cx={78} cy={98} r={6} fill="#ffcf3f" stroke={INK} strokeWidth={3} />
      </>
    ),
  },
  tree: {
    h: 150,
    draw: () => (
      <>
        <path d="M44 148V92h12v56z" fill="#8a5a33" {...base} strokeWidth={4} />
        <path d="M50 4C24 4 14 24 20 40 4 46 2 72 22 80c6 18 50 18 56 0 20-8 18-34 2-40 6-16-4-36-30-36z" fill="#4caf6a" {...base} />
      </>
    ),
  },
  bench: {
    h: 50,
    draw: () => (
      <>
        <rect x={2} y={4} width={96} height={9} rx={3} fill="#b9814f" {...base} strokeWidth={3.5} />
        <rect x={2} y={24} width={96} height={9} rx={3} fill="#b9814f" {...base} strokeWidth={3.5} />
        <path d="M14 13v35M86 13v35" {...base} />
      </>
    ),
  },
  tv: {
    h: 76,
    draw: (text) => (
      <>
        <rect x={4} y={4} width={92} height={58} rx={6} fill="#2b2d3a" {...base} />
        <rect x={11} y={11} width={78} height={44} fill="#8fd3ff" />
        <path d="M34 72h32M50 62v10" {...base} />
        {text ? (
          <text x={50} y={42} textAnchor="middle" fontSize={22} fontWeight={900} fill="#1b1b22" fontFamily="Arial, sans-serif">
            {text.slice(0, 7)}
          </text>
        ) : null}
      </>
    ),
  },
  sign: {
    h: 120,
    draw: (text) => (
      <>
        <path d="M50 60v58" {...base} strokeWidth={8} />
        <rect x={4} y={4} width={92} height={58} rx={6} fill="#fffdf5" {...base} />
        <text x={50} y={44} textAnchor="middle" fontSize={(text ?? '').length > 5 ? 20 : 30} fontWeight={900} fill={INK} fontFamily="Arial, sans-serif">
          {(text ?? '!').slice(0, 9)}
        </text>
      </>
    ),
  },
  mirror: {
    h: 170,
    draw: () => (
      <>
        <ellipse cx={50} cy={74} rx={42} ry={68} fill="#d7f0ff" {...base} />
        <path d="M30 40l24-18M34 62l14-10" stroke="#fff" strokeWidth={6} strokeLinecap="round" />
        <path d="M30 166h40M50 142v24" {...base} />
      </>
    ),
  },
  safe: {
    h: 100,
    draw: () => (
      <>
        <rect x={5} y={5} width={90} height={90} rx={8} fill="#7f8796" {...base} />
        <circle cx={50} cy={50} r={20} fill="#c9ccd6" {...base} strokeWidth={4} />
        <path d="M50 30v40M30 50h40" stroke={INK} strokeWidth={4} />
      </>
    ),
  },
  calendar: {
    h: 100,
    draw: (text) => (
      <>
        <rect x={6} y={12} width={88} height={84} rx={8} fill="#fffdf5" {...base} />
        <path d="M6 20c0-5 3-8 8-8h72c5 0 8 3 8 8v16H6z" fill="#ff5d5d" {...base} />
        <path d="M28 4v16M72 4v16" {...base} />
        <text x={50} y={82} textAnchor="middle" fontSize={40} fontWeight={900} fill={INK} fontFamily="Arial, sans-serif">
          {(text ?? '1').slice(0, 3)}
        </text>
      </>
    ),
  },
  pizza: {
    h: 100,
    draw: () => (
      <>
        <path d="M50 96L8 16c26-14 58-14 84 0z" fill="#ffd166" {...base} />
        <path d="M8 16c26-14 58-14 84 0" fill="none" stroke="#c98a3a" strokeWidth={10} strokeLinecap="round" />
        <circle cx={42} cy={36} r={8} fill="#e5383b" />
        <circle cx={62} cy={46} r={7} fill="#e5383b" />
        <circle cx={50} cy={66} r={6} fill="#e5383b" />
      </>
    ),
  },
  dumbbell: {
    h: 46,
    draw: () => (
      <>
        <path d="M22 23h56" {...base} strokeWidth={8} />
        <rect x={4} y={4} width={18} height={38} rx={5} fill="#5c6270" {...base} strokeWidth={4} />
        <rect x={78} y={4} width={18} height={38} rx={5} fill="#5c6270" {...base} strokeWidth={4} />
      </>
    ),
  },
  crown: {
    h: 70,
    draw: () => <path d="M8 62L4 14l24 22L50 4l22 32 24-22-4 48z" fill="#ffcf3f" {...base} />,
  },
  planet: {
    h: 100,
    draw: () => (
      <>
        <circle cx={50} cy={50} r={44} fill="#4f9dde" {...base} />
        <path d="M20 30c10-6 22 0 20 10s-14 8-18 18M58 20c10 2 18 10 20 22-10 2-18-4-20-22zM48 66c10-4 22 2 20 14-8 8-18 8-20-14z" fill="#62c370" />
      </>
    ),
  },
  cloud: {
    h: 56,
    draw: () => (
      <path d="M24 52C6 52 2 30 18 26 18 8 42 2 52 16c14-8 30 2 28 16 16 0 18 20 2 20z" fill="#fff" {...base} strokeWidth={4} />
    ),
  },
  arrow: {
    h: 60,
    draw: () => <path d="M4 22h56V4l36 26-36 26V38H4z" fill="#ff4d4d" {...base} />,
  },
  ticket: {
    h: 56,
    draw: (text) => (
      <>
        <path d="M4 6h92v14c-10 0-10 16 0 16v14H4V36c10 0 10-16 0-16z" fill="#ffe66b" {...base} strokeWidth={4} />
        <text x={50} y={38} textAnchor="middle" fontSize={24} fontWeight={900} fill={INK} fontFamily="Arial, sans-serif">
          {(text ?? 'WIN').slice(0, 6)}
        </text>
      </>
    ),
  },
  mask: {
    h: 70,
    draw: () => (
      <>
        <path d="M6 12c28-12 60-12 88 0 2 30-14 54-44 54S4 42 6 12z" fill="#f4f6fb" {...base} />
        <path d="M22 28c8-6 16-4 20 2-6 6-16 6-20-2zM78 28c-8-6-16-4-20 2 6 6 16 6 20-2z" fill={INK} />
      </>
    ),
  },
};

for (const [name, def] of Object.entries(D)) registerPropSize(name, 100, def.h);

export const PROP_NAMES = Object.keys(D);

export const Prop: React.FC<{
  type: string;
  cx: number;
  cy: number;
  w: number;
  rot?: number;
  text?: string;
  opacity?: number;
}> = ({type, cx, cy, w, rot = 0, text, opacity = 1}) => {
  const def = D[type] ?? D.box;
  const s = w / 100;
  const h = def.h * s;
  return (
    <g transform={`translate(${cx - w / 2} ${cy - h / 2}) rotate(${rot} ${w / 2} ${h / 2}) scale(${s})`} opacity={opacity}>
      {def.draw(text)}
    </g>
  );
};
