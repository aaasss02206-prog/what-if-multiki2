// Storyboard linter. Measures every shot with the same geometry the renderer
// uses and prints problems a viewer would see: a prop over a face, a hand cut
// off by the frame, text on top of a head, a shot that hangs too long.
//
//   npx tsx tools/lint.ts <props.json> [--json out.json]
import fs from 'node:fs';
import {
  ActorSpec,
  ActorState,
  BEATS,
  Box,
  CYCLES,
  Episode,
  H,
  MOODS,
  POSES,
  SFX_NAMES,
  ShotSpec,
  TEXT_STYLE,
  W,
  actorAt,
  bodyBox,
  bubbleBox,
  cameraAt,
  headBox,
  heldPropBox,
  insideFraction,
  labelBox,
  mergeTiming,
  overlap,
  propBox,
  resolveFocus,
  textBox,
  viewRect,
  worldToScreen,
} from '../src/layout';
import {PROP_NAMES} from '../src/props';
import {BG_NAMES, PALETTES} from '../src/Background';
import {FX_NAMES} from '../src/Shot';

type Issue = {level: 'error' | 'warn'; shot: number | null; code: string; msg: string; fix: string};
const issues: Issue[] = [];
const err = (shot: number | null, code: string, msg: string, fix: string) => issues.push({level: 'error', shot, code, msg, fix});
const warn = (shot: number | null, code: string, msg: string, fix: string) => issues.push({level: 'warn', shot, code, msg, fix});

const args = process.argv.slice(2);
const file = args.find((a) => !a.startsWith('--'));
if (!file) {
  console.error('usage: tsx tools/lint.ts <props.json> [--json out.json]');
  process.exit(2);
}
const jsonOut = args.includes('--json') ? args[args.indexOf('--json') + 1] : null;
const props = JSON.parse(fs.readFileSync(file, 'utf8'));
const ep: Episode & {length?: string} = props.episode;
const characters: Record<string, unknown> = props.characters ?? {};
const timing = props.timing ?? null;
const FPS = 30;

const oneOf = (v: string | undefined, list: string[], shot: number, what: string) => {
  if (v !== undefined && !list.includes(v)) {
    err(shot, 'UNKNOWN', `${what} "${v}" does not exist`, `use one of: ${list.join(', ')}`);
    return false;
  }
  return true;
};

const SHOT_KEYS = ['id', 'beat', 'say', 'pause', 'bg', 'time', 'camera', 'actors', 'props', 'crowd', 'text', 'source', 'fx', 'sfx', 'thumb', 'note'];
const ACTOR_KEYS = ['who', 'x', 'toX', 'y', 'scale', 'toScale', 'face', 'pose', 'toPose', 'switchAt', 'mood', 'toMood', 'hold', 'holdSize', 'label', 'bubble', 'motion', 'ghost', 'glow', 'z'];

if (!ep || !Array.isArray(ep.shots) || ep.shots.length === 0) {
  err(null, 'EMPTY', 'episode.json has no shots', 'write the shots array first');
} else {
  const shots = ep.shots;
  const n = shots.length;
  const long = ep.length === 'long';
  if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(ep.slug ?? '')) err(null, 'SLUG', `slug "${ep.slug}" must be lowercase-kebab-case`, 'e.g. "see-one-minute-ahead"');
  if (!characters[ep.hero]) err(null, 'HERO', `hero "${ep.hero}" is not in characters.json`, `use one of: ${Object.keys(characters).join(', ')}`);
  if (!/^what if/i.test(ep.title ?? '')) warn(null, 'TITLE', `title "${ep.title}" does not start with "What If"`, 'titles in this format start with "What If You ..."');
  if ((ep.title ?? '').length > 60) warn(null, 'TITLE_LONG', `title is ${(ep.title ?? '').length} characters`, 'keep it under 60 characters, one idea');

  // ---------- schema ----------
  shots.forEach((s, idx) => {
    const no = idx + 1;
    for (const k of Object.keys(s)) if (!SHOT_KEYS.includes(k)) warn(no, 'KEY', `unknown field "${k}" is ignored`, `allowed shot fields: ${SHOT_KEYS.join(', ')}`);
    if (typeof s.say !== 'string' || !s.say.trim()) err(no, 'SAY', 'shot has no narration ("say")', 'every shot carries a piece of the narration; split a sentence across two shots if needed');
    if (!s.beat) err(no, 'BEAT', 'shot has no "beat"', `set beat to one of: ${BEATS.join(', ')}`);
    else oneOf(s.beat, BEATS, no, 'beat');
    if (!s.bg) err(no, 'BG', 'shot has no "bg"', `set bg to one of: ${BG_NAMES.join(', ')}`);
    else oneOf(s.bg, BG_NAMES, no, 'bg');
    oneOf(s.time, Object.keys(PALETTES), no, 'time');
    oneOf(s.camera?.size, ['wide', 'medium', 'close', 'extreme'], no, 'camera.size');
    oneOf(s.camera?.move, ['static', 'push', 'pull', 'pan-left', 'pan-right', 'shake', 'drift'], no, 'camera.move');
    (s.fx ?? []).forEach((f) => oneOf(f, FX_NAMES, no, 'fx'));
    const sfx = s.sfx ? (Array.isArray(s.sfx) ? s.sfx : [s.sfx]) : [];
    sfx.forEach((f) => oneOf(f, SFX_NAMES, no, 'sfx'));
    (s.actors ?? []).forEach((a: ActorSpec) => {
      for (const k of Object.keys(a)) if (!ACTOR_KEYS.includes(k)) warn(no, 'KEY', `unknown actor field "${k}" is ignored`, `allowed actor fields: ${ACTOR_KEYS.join(', ')}`);
      if (!characters[a.who]) err(no, 'UNKNOWN', `character "${a.who}" is not in characters.json`, `use one of: ${Object.keys(characters).join(', ')} (or add a new one to characters.json)`);
      oneOf(a.pose, Object.keys(POSES), no, 'pose');
      oneOf(a.toPose, Object.keys(POSES), no, 'toPose');
      oneOf(a.mood, MOODS, no, 'mood');
      oneOf(a.toMood, MOODS, no, 'toMood');
      oneOf(a.hold, PROP_NAMES, no, 'hold');
      oneOf(a.motion, ['none', 'jump', 'shake', 'nod', 'float', 'spin', 'pop', 'tremble'], no, 'motion');
      oneOf(a.bubble?.icon, PROP_NAMES, no, 'bubble.icon');
      if (a.bubble?.text && a.bubble.text.length > 42) err(no, 'BUBBLE_LONG', `bubble text is ${a.bubble.text.length} characters`, 'max 42 characters; a bubble is 2-5 words');
      const lt = typeof a.label === 'string' ? a.label : a.label?.text ?? '';
      if (lt.length > 14) err(no, 'LABEL_LONG', `label "${lt}" is too long`, 'max 14 characters, e.g. "IQ 142" or "$2.4M"');
    });
    (s.props ?? []).forEach((p) => {
      oneOf(p.type, PROP_NAMES, no, 'prop');
      if (typeof p.x !== 'number') err(no, 'PROP_X', `prop "${p.type}" has no x`, 'x is 0..100 (percent of the frame width)');
    });
    if (s.text) {
      const st = TEXT_STYLE[s.text.style ?? 'title'];
      if (!st) err(no, 'UNKNOWN', `text.style "${s.text.style}" does not exist`, 'use title, impact or note');
      else if (!s.text.count && s.text.value.length > st.maxChars * 2) err(no, 'TEXT_LONG', `on-screen text is ${s.text.value.length} characters`, `max ${st.maxChars * 2} for style "${s.text.style ?? 'title'}"; on-screen text is 1-5 words, the voice says the rest`);
    }
    if (s.source && s.source.length > 64) err(no, 'SOURCE_LONG', `source caption is ${s.source.length} characters`, 'max 64: "Journal or institution, year"');
  });

  const valid = !issues.some((i) => i.level === 'error' && ['UNKNOWN', 'SAY', 'BG', 'PROP_X'].includes(i.code));

  // ---------- geometry ----------
  if (valid) {
    const slots = mergeTiming(ep, timing, FPS);
    shots.forEach((s, idx) => {
      const no = idx + 1;
      const specs = s.actors ?? [];
      const size = s.camera?.size ?? 'wide';
      const tight = size === 'close' || size === 'extreme';
      const start = specs.map((a, i) => actorAt(a, 0, 0, i));
      const focus = resolveFocus(s, start, ep.hero);
      const on = s.camera?.on;
      const focusIdx = typeof on === 'number' ? on : typeof on === 'string' ? specs.findIndex((a) => a.who === on) : specs.findIndex((a) => a.who === ep.hero);
      if (typeof on === 'string' && on !== 'center' && focusIdx < 0) err(no, 'CAMERA_ON', `camera.on "${on}" is not an actor in this shot`, 'point the camera at an actor that is in the shot, or use "center"');
      if (typeof on === 'number' && !specs[on]) err(no, 'CAMERA_ON', `camera.on ${on} - there is no actor with that index`, 'actor indexes start at 0');
      if (tight && specs.length === 0) err(no, 'CLOSE_EMPTY', `${size} shot with no actors`, 'use wide for shots without characters');

      const seconds = slots[idx].frames / FPS;
      for (const t of [0.05, 0.62, 0.98]) {
        const actors: ActorState[] = specs.map((a, i) => actorAt(a, t, t * seconds, i));
        const cam = cameraAt(s, focus, t, 0);
        const view = viewRect(cam);
        const key = t === 0.62;
        actors.forEach((a, i) => {
          const leaving = a.spec.toX !== undefined && (a.spec.toX < 2 || a.spec.toX > 98 || (a.spec.x ?? 50) < 2 || (a.spec.x ?? 50) > 98);
          const inFocus = !tight || i === (focusIdx < 0 ? 0 : focusIdx);
          const hb = headBox(a);
          if (inFocus && !leaving && insideFraction(hb, view) < 0.9 && key) {
            err(no, 'HEAD_CUT', `${a.spec.who}'s head is cut off by the frame`, tight ? 'set camera.on to this actor, or use a wider camera.size' : 'move the actor (x between 10 and 90), lower y/scale, or use camera.size "wide"');
          }
          const held = heldPropBox(a);
          if (held && inFocus && !leaving && key && insideFraction(held, view) < 0.85) {
            err(no, 'HAND_CUT', `${a.spec.who} holds "${a.spec.hold}" but the hand is outside the frame - the viewer will not see it`, 'use camera.size "medium" or "wide", or a pose that keeps the hand near the face (phone, hold-up)');
          }
          if (!tight && !leaving && key && insideFraction(bodyBox(a), view) < (size === 'medium' ? 0.45 : 0.8)) {
            warn(no, 'BODY_CUT', `${a.spec.who} is mostly outside the frame`, 'move the actor towards the centre or use a wider shot');
          }
          const lb = labelBox(a, 1);
          if (lb && key && insideFraction(lb, view) < 0.97) err(no, 'LABEL_CUT', `label above ${a.spec.who} is cut off by the frame`, 'lower the actor scale, move x away from the edge, or use a wider camera.size');
          const bb = bubbleBox(a);
          if (bb && key && insideFraction(bb, view) < 0.97) err(no, 'BUBBLE_CUT', `bubble of ${a.spec.who} is cut off by the frame`, 'flip the actor (face) so the bubble opens towards the centre, or use a wider camera.size');
          if (lb && bb && key && overlap(lb, bb) > 0) err(no, 'LABEL_BUBBLE', `${a.spec.who} has a label and a bubble that overlap`, 'use one of them per shot');
          // own hand / prop over own face
          const ownOk = ['phone', 'eat', 'listen', 'facepalm', 'cover-eyes', 'think', 'scared', 'read', 'count'].includes(a.poseName);
          if (held && !ownOk && key && overlap(held, hb) / (hb.w * hb.h) > 0.22) {
            err(no, 'FACE_COVERED', `"${a.spec.hold}" in ${a.spec.who}'s hand covers the face`, 'use pose "hold" or "hold-out", or a smaller holdSize');
          }
          actors.forEach((b, k2) => {
            if (k2 <= i) return;
            const hb2 = headBox(b);
            if (key && overlap(hb, hb2) / Math.min(hb.w * hb.h, hb2.w * hb2.h) > 0.2) {
              err(no, 'ACTORS_OVERLAP', `${a.spec.who} and ${b.spec.who} overlap - one face hides the other`, 'put at least 16 points of x between them');
            }
            const held2 = heldPropBox(b);
            if (key && held2 && overlap(held2, hb) / (hb.w * hb.h) > 0.3) err(no, 'FACE_COVERED', `"${b.spec.hold}" held by ${b.spec.who} covers ${a.spec.who}'s face`, 'move the actors apart');
            if (key && held && overlap(held, hb2) / (hb2.w * hb2.h) > 0.3) err(no, 'FACE_COVERED', `"${a.spec.hold}" held by ${a.spec.who} covers ${b.spec.who}'s face`, 'move the actors apart');
            const bb2 = bubbleBox(b);
            if (key && bb2 && overlap(bb2, hb) / (hb.w * hb.h) > 0.25) err(no, 'BUBBLE_ON_FACE', `bubble of ${b.spec.who} covers ${a.spec.who}'s face`, 'move the actors apart or flip the speaker');
            if (key && bb && overlap(bb, hb2) / (hb2.w * hb2.h) > 0.25) err(no, 'BUBBLE_ON_FACE', `bubble of ${a.spec.who} covers ${b.spec.who}'s face`, 'move the actors apart or flip the speaker');
          });
          (s.props ?? []).forEach((p) => {
            if (p.layer === 'back' || p.cover) return;
            const pb = propBox(p, t);
            if (overlap(pb, hb) / (hb.w * hb.h) > 0.18) {
              err(no, 'FACE_COVERED', `prop "${p.type}" covers ${a.spec.who}'s face${key ? '' : t < 0.5 ? ' at the start of the shot' : ' at the end of the shot'}`, 'change the prop x/y (or toX/toY) so it stops beside the head, not on it; or set layer "back"');
            }
          });
          // on-screen text over faces (screen space)
          if (s.text && key && inFocus) {
            const tb = textBox(s.text);
            const sh = worldToScreen(cam, hb);
            if (overlap(tb, sh) / (sh.w * sh.h) > 0.2) {
              err(no, 'TEXT_ON_FACE', `on-screen text covers ${a.spec.who}'s face`, `move text.pos (now "${s.text.pos ?? 'top'}") to another position, or use a wider camera.size`);
            }
            const sl = lb ? worldToScreen(cam, lb) : null;
            if (sl && overlap(tb, sl) > 0) err(no, 'TEXT_ON_LABEL', `on-screen text covers the label above ${a.spec.who}`, 'move text.pos to "bottom"');
            const sb = bb ? worldToScreen(cam, bb) : null;
            if (sb && overlap(tb, sb) > 0) err(no, 'TEXT_ON_BUBBLE', `on-screen text covers the bubble of ${a.spec.who}`, 'move text.pos to "bottom" or drop one of them');
          }
        });
        if (key) {
          (s.props ?? []).forEach((p) => {
            const pb = propBox(p, t);
            if (insideFraction(pb, view) < 0.5 && p.toX === undefined && p.toY === undefined) {
              warn(no, 'PROP_CUT', `prop "${p.type}" is mostly outside the frame`, 'move it into view or use a wider camera.size');
            }
          });
        }
      }
      if (s.text && s.source && (s.text.pos ?? 'top') === 'bottom') err(no, 'TEXT_ON_SOURCE', 'bottom text overlaps the source caption', 'move text.pos to "top"');
      void W;
      void H;
    });

    // ---------- pace ----------
    const dur = slots.map((sl) => sl.frames / FPS);
    const total = dur.reduce((a, b) => a + b, 0);
    let clock = 0;
    let startCuts = 0;
    dur.forEach((d, idx) => {
      const no = idx + 1;
      const early = clock < 30;
      if (early) startCuts++;
      const max = early ? 3.6 : 5.0;
      if (d > max) {
        err(no, 'LONG_SHOT', `shot stays on screen ${d.toFixed(1)}s (limit ${max}s ${early ? 'in the first 30s' : 'after the first 30s'})`, 'split it into two shots: cut "say" in the middle of the sentence and change the camera, pose or background');
      }
      if (d < 0.75) warn(no, 'SHORT_SHOT', `shot is only ${d.toFixed(2)}s`, 'merge it with a neighbour or give it more words');
      clock += d;
    });
    const window = Math.min(30, total);
    const cpmStart = (startCuts / window) * 60;
    const cpmAll = (n / total) * 60;
    if (cpmStart < 24) err(null, 'PACE_START', `${cpmStart.toFixed(0)} cuts per minute in the first 30 seconds (need 24+, target 27)`, 'split the longest early shots; the first 30 seconds decide whether the viewer stays');
    if (cpmAll < 18) err(null, 'PACE', `${cpmAll.toFixed(0)} cuts per minute overall (need 18+)`, 'split the longest shots');
    const [lo, hi] = long ? [420, 720] : [55, 120];
    if (total < lo || total > hi) err(null, 'LENGTH', `episode is about ${total.toFixed(0)}s, target for a ${long ? 'long' : 'short'} episode is ${lo}-${hi}s`, total < lo ? 'add situations to the "small"/"bigger" beats' : 'cut the weakest situations');

    // ---------- story ----------
    const first = shots[0];
    if (first.beat !== 'hook') err(1, 'HOOK', 'the first shot is not the hook', 'shot 1 must have beat "hook" and ask the what-if question');
    const lang = (ep.language ?? 'en').toLowerCase();
    if (lang === 'en' && !/what if/i.test(first.say + ' ' + (shots[1]?.say ?? ''))) err(1, 'HOOK', 'the question "What if ..." is not in the first two shots', 'open with the question itself, no greeting, no intro');
    if (/^(hi|hello|hey|welcome|today|in this video)\b/i.test(first.say.trim())) err(1, 'HOOK', 'the episode opens with a greeting or an intro', 'delete it; the first words are the what-if question');
    let rank = -1;
    shots.forEach((s, idx) => {
      const r = BEATS.indexOf(s.beat ?? '');
      if (r >= 0 && r < rank) err(idx + 1, 'BEAT_ORDER', `beat "${s.beat}" comes after "${BEATS[rank]}"`, `beats go in this order: ${BEATS.join(' -> ')}`);
      if (r > rank) rank = r;
    });
    const count = (b: string) => shots.filter((s) => s.beat === b).length;
    if (count('small') < 3) err(null, 'STORY', `only ${count('small')} shots in beat "small"`, 'show at least 2 small everyday situations (3+ shots)');
    if (count('bigger') < 3) err(null, 'STORY', `only ${count('bigger')} shots in beat "bigger"`, 'escalate: at least 2 bigger situations (3+ shots)');
    const facts = shots.filter((s) => s.beat === 'fact');
    if (facts.length === 0) err(null, 'FACT', 'there is no "fact" beat', 'add the real-science turn before the final question');
    else if (!facts.some((s) => s.source)) err(shots.indexOf(facts[0]) + 1, 'FACT_SOURCE', 'the fact has no on-screen source', 'add "source": "Journal or institution, year" to one fact shot');
    const last = shots[n - 1];
    if (last.beat !== 'question') err(n, 'ENDING', 'the last shot is not the question to the viewer', 'end with beat "question": ask the viewer what THEY would do');
    else if (!last.say.trim().endsWith('?')) err(n, 'ENDING', 'the last line does not end with a question mark', 'the final line is a direct question to the viewer');
    const withActors = shots.filter((s) => (s.actors ?? []).length > 0);
    const heroShots = withActors.filter((s) => (s.actors ?? []).some((a) => a.who === ep.hero));
    if (withActors.length && heroShots.length / n < 0.65) err(null, 'ONE_HERO', `the hero "${ep.hero}" is in ${heroShots.length} of ${n} shots`, 'the viewer follows one person: keep the hero in at least 65% of the shots');
    const castUsed = new Set(shots.flatMap((s) => (s.actors ?? []).map((a) => a.who)).filter((w) => w !== 'extra'));
    if (castUsed.size > 5) warn(null, 'CAST', `${castUsed.size} named characters`, 'use the hero plus 1-3 others; use "crowd" for everybody else');

    // ---------- variety & motion ----------
    const sig = (s: ShotSpec) => JSON.stringify([s.bg, s.time, s.camera?.size ?? 'wide', s.camera?.on ?? '', (s.actors ?? []).map((a) => [a.who, a.pose ?? 'stand', Math.round((a.x ?? 50) / 8)]), (s.props ?? []).map((p) => [p.type, p.text ?? '']), s.text?.value ?? '', !!s.text?.count]);
    shots.forEach((s, idx) => {
      const no = idx + 1;
      if (idx > 0 && sig(s) === sig(shots[idx - 1])) err(no, 'SAME_FRAME', `shot looks the same as shot ${idx} - the cut will be invisible`, 'change camera.size, the pose, the actor position or the background');
      const moving =
        (s.camera?.move ?? 'static') !== 'static' ||
        (s.actors ?? []).some((a) => a.toX !== undefined || a.toPose || a.toScale !== undefined || (a.motion && a.motion !== 'none') || CYCLES.has(a.pose ?? 'stand') || (typeof a.label === 'object' && a.label.from !== undefined)) ||
        (s.props ?? []).some((p) => p.toX !== undefined || p.toY !== undefined || p.spin || p.toSize !== undefined) ||
        !!s.text?.count ||
        (s.fx ?? []).some((f) => !['darken', 'gold', 'freeze'].includes(f));
      if (!moving) err(no, 'STATIC', 'nothing moves in this shot', 'add one of: camera.move (push/pull/pan), toPose, toX, motion, a moving prop, or an fx');
    });
    for (let i = 3; i < n; i++) {
      const sz = (k: number) => shots[k].camera?.size ?? 'wide';
      if (sz(i) === sz(i - 1) && sz(i) === sz(i - 2) && sz(i) === sz(i - 3)) warn(i + 1, 'CAMERA_VARIETY', `4 shots in a row are "${sz(i)}"`, 'alternate wide / medium / close');
    }
    const bgs = new Set(shots.map((s) => s.bg));
    if (bgs.size < 3) err(null, 'LOCATIONS', `only ${bgs.size} background(s) in the episode`, 'each situation happens in its own place: use at least 3 backgrounds');
    const sfxUsed = shots.flatMap((s) => (s.sfx ? (Array.isArray(s.sfx) ? s.sfx : [s.sfx]) : []));
    if (sfxUsed.length < Math.min(6, Math.floor(n / 4))) warn(null, 'SFX_FEW', `only ${sfxUsed.length} sound effects`, 'put an sfx on the hook, on every reveal and on the fact');
    if (new Set(sfxUsed).size > 12) err(null, 'SFX_MANY', `${new Set(sfxUsed).size} different sound effects`, 'use at most 12 different ones per episode - each new one costs ElevenLabs credits, repeats are free');

    const errors = issues.filter((i) => i.level === 'error').length;
    const stats = {
      shots: n,
      seconds: Math.round(total * 10) / 10,
      cutsPerMinuteFirst30: Math.round(cpmStart * 10) / 10,
      cutsPerMinute: Math.round(cpmAll * 10) / 10,
      characters: shots.reduce((a, s) => a + s.say.length + 1, 0),
      timing: timing ? 'voice' : 'estimate',
      errors,
      warnings: issues.length - errors,
    };
    (globalThis as Record<string, unknown>).__stats = stats;
  }
}

const stats = (globalThis as Record<string, unknown>).__stats ?? {};
const errors = issues.filter((i) => i.level === 'error');
const warns = issues.filter((i) => i.level === 'warn');
const line = (i: Issue) => `${i.level === 'error' ? 'ERROR' : 'warn '} ${i.shot ? `shot ${String(i.shot).padStart(2)}` : 'episode'} [${i.code}] ${i.msg}\n        fix: ${i.fix}`;
console.log(`STORYBOARD CHECK - ${JSON.stringify(stats)}`);
errors.forEach((i) => console.log(line(i)));
warns.forEach((i) => console.log(line(i)));
console.log(errors.length ? `\nRESULT: ${errors.length} error(s). Fix them in episode.json and run the check again.` : `\nRESULT: OK${warns.length ? ` (${warns.length} warning(s) - fix them if it is quick)` : ''}`);
if (jsonOut) fs.writeFileSync(jsonOut, JSON.stringify({stats, issues}, null, 2));
process.exit(errors.length ? 1 : 0);
