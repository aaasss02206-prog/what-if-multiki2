---
name: what-if
description: Make a complete "What if you..." stickman cartoon for YouTube from one idea - script, voice, storyboard, self-check, animation, sound, final mp4. Use when the user gives a what-if idea, asks for a what-if cartoon/episode, or asks to change a character or a shot of one.
---

# What-if cartoon

You turn ONE line from the user ("what if you could see one minute ahead") into a finished 16:9 video.
You do not draw pictures and you do not write animation code. You write ONE data file, `episode.json`,
and a ready-made engine (Remotion) turns it into the cartoon. Every step below ends with a command
that tells you if the step is good. Do the steps in order. Do not skip a check. Do not ask the user
questions between steps - make the decision yourself and keep going until the video exists.

Talk to the user in the language they write in. The cartoon itself is in English unless the user
asks for another language.

All commands are run from the project folder (the folder opencode was started in):

    python .opencode/skills/what-if/scripts/whatif.py <command> ...

If `python` is not found, use `python3` (macOS/Linux) or `py` (Windows) for the whole session.
Below this is shortened to `whatif <command>`.

## The formula (why these videos get watched)

1. **Hook** - the first words are the question itself. No greeting, no intro.
2. **Escalation** - small everyday wins -> bigger stakes -> the dark side. One hero the whole time.
3. **Fact** - one real, sourced piece of science that makes an adult say "wait, that's true?".
4. **Question** - the last line asks the viewer what THEY would do. That is what fills the comments.
5. **Pace** - about 27 cuts per minute in the first 30 seconds. Something moves in every shot.

Never remove the fact, never slow the pace: those two are what separates this from a kids' cartoon.

## Step 0 - setup (every session, takes seconds after the first time)

    whatif setup

It checks the tools, installs the studio on the first run, and reports the ElevenLabs credits.
If it prints FAILED, show the user the exact line that failed and stop. If there is no ElevenLabs
key, continue anyway and use `--mock` in steps 5-6 (silent draft), then tell the user at the end.

## Step 1 - idea, slug, duplicate check

- Rewrite the idea as an English title that starts with "What If You" and is under 60 characters.
- Slug = short lowercase-kebab-case of the title, e.g. `see-one-minute-ahead`.
- Length: `short` (60-110 s, 26-40 shots) unless the user asked for a long episode
  (`long`: 7-11 minutes, see "Long episodes" at the end).
- If you have a web search or fetch tool, search YouTube for the exact title. If a video with the
  same premise already has many views, keep the mechanic but change the angle (other ability, a
  price to pay, a timer). Write what you found in one line. If you cannot search, say so in the
  final report so the user checks it by hand - do not claim you checked.

    whatif new <slug>

## Step 2 - the fact (before the script, because the script is built around it)

Read `references/story.md` section "Fact". Then fill `episodes/<slug>/fact.md`: the claim in one
sentence, the source (journal or institution, year), the URL, and what the source does NOT say.

Rules: only a fact you are sure exists. Prefer textbook-level findings from named journals or
institutions. Never invent a URL, an author or a number. If you are not sure of the exact URL,
write the title and journal and put `URL: https://scholar.google.com/scholar?q=<title>` so the
human can find it. The status line stays "NOT VERIFIED BY A HUMAN YET".

## Step 3 - write episode.json

Read `references/story.md` (how the narration is built) and `references/episode-format.md`
(every field, every pose, prop, background). Look at the finished example
`examples/see-one-minute-ahead/episode.json` - copy its shape, not its content.

Write `episodes/<slug>/episode.json`. Narration first, pictures second:

1. Write the whole narration as short lines, one line per shot (4-9 words, max 50 characters in
   the first 30 seconds, max 70 later). Long sentence = two shots.
2. Give every line a `beat`, then stage it: background, camera, actors, one thing that moves.
3. Change something visible on every cut: camera size, pose, place. Alternate wide/medium/close.

## Step 4 - check, storyboard, fix (the step that makes it look professional)

    whatif check <slug>

Fix EVERY line that starts with `ERROR` (each one has a `fix:`), run check again, repeat until it
prints `RESULT: OK`. Typical findings: a prop covering a face, a hand with a prop outside the
frame, text on top of a head, a shot longer than the limit, two identical shots in a row.
Do not argue with the checker and do not delete shots to silence it - fix the staging.

    whatif board <slug>

This renders one frame per shot and saves `episodes/<slug>/board.png` (red frame = error).
If you can open images, look at `board.png` and at any single frame in `episodes/<slug>/board/`
and fix what reads badly even if the checker passed: an empty-looking frame, a hero who is too
small, two shots that feel the same. Read `references/checks.md` for the list. Then run `board`
again. Maximum 3 rounds - then move on.

## Step 5 - voice

    whatif voice <slug>

One voice for every episode (set in `.env`, default "Brian"). The command is cached: it spends
credits only when the narration text changed. After it, the cuts sit on the real words, so:

    whatif check <slug>

If the real voice made some shot too long, split that shot (cut its `say` in two) and run voice
again - only do this for real `LONG_SHOT`/`PACE` errors, each voice run costs credits.
No key or no credits: `whatif voice <slug> --mock` (silent track, estimated timing).

## Step 6 - sound, mix, render

    whatif sfx <slug>
    whatif mix <slug>
    whatif render <slug>

`sfx` reuses sounds from `./sfx` and only generates the missing ones. `mix` sets the loudness
itself and prints the measured LUFS; if it says `CHECK BY EAR`, run it once more, then continue.
`render` takes a few minutes and prints `DONE: episodes/<slug>/<slug>.mp4`.
(`whatif build <slug>` runs voice+sfx+mix+render in one go - use it for re-renders.)

## Step 7 - publish kit and report

Write `episodes/<slug>/publish.md`:
- 3 title options (start with "What If You", under 60 characters, one idea each)
- description: 2 sentences + the fact source with its URL + the question from the ending
  + the line `Voice: elevenlabs.io` (required on the free ElevenLabs plan)
- thumbnail idea: ONE hero, ONE clear situation, big, max 3 words of text; name the shot number
  to grab with `whatif frame <slug> <n>`
- 10 tags

Then report to the user, short:
- where the video is and how long it is
- the fact and its source URL, with the words: "open the source and check it before publishing"
- whether the duplicate check on YouTube was done by you or must be done by them
- anything that was mocked or skipped, and credits left if known

## Changing things after the render

- "In shot 7 the ball covers the face" -> edit that shot in `episode.json`, `whatif frame <slug> 7`
  to verify, `whatif check <slug>`, then `whatif build <slug>`. The voice is cached, so a picture
  fix costs no credits.
- "Add a new character: a girl with a high ponytail, yellow raincoat, red boots" -> read
  `references/characters.md`, add an entry to `characters.json` in the project folder, then
  `whatif sheet` and show the user `character-sheet.png`.
- "Make her the hero of episode X" -> change `hero` and every `"who"` of the old hero in that
  `episode.json`, `whatif check`, `whatif build` (same voice, no new credits).

## Long episodes (7-11 minutes)

Set `"length": "long"` in `episode.json` and keep `"shots": []` there. Write the shots in separate
files in the same folder, one act per file, each file a JSON array of 30-45 shots:
`shots-01-hook.json`, `shots-02-small.json`, `shots-03-bigger.json`, `shots-04-dark.json`,
`shots-05-fact.json`, `shots-06-question.json`. They are joined in file-name order. Write one
file, run `whatif check <slug>`, fix, then write the next. A long episode needs 6-9 separate
situations and uses 6 000-9 000 ElevenLabs credits - tell the user this number before `voice`.

## Hard rules

- Do not edit anything inside `.opencode/skills/what-if/` or `studio/`. Your work is in `episodes/`
  and `characters.json`.
- Use only names that exist in `references/episode-format.md`. An unknown pose/prop/background is
  an error, not a suggestion to invent one.
- Real people, brands, copyrighted characters and their names never appear in an episode.
- Nothing gory, sexual or hateful. Death is handled off-screen and gently (a timer, an empty chair).
- Never say a fact was verified. Only the human verifies.
