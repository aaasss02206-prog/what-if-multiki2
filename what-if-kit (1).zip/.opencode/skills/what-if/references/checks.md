# Self-check list for the storyboard

`whatif check` measures these exactly. When you look at `board.png` yourself, look for the same things.

| code | what the viewer would see | usual fix |
|---|---|---|
| FACE_COVERED | a prop, hand or bubble on top of a face | move the prop to stop BESIDE the head; pose `hold`/`hold-out`; smaller `holdSize` |
| HAND_CUT | the hero holds something important but the camera crops it | `medium` instead of `close`, or pose `hold-up` / `phone` |
| HEAD_CUT | a head sliced by the edge of the frame | `camera.on` = that actor, or `"center"` for two actors, or `wide` |
| LABEL_CUT / BUBBLE_CUT | a number above a head or a bubble leaves the frame | wider shot, smaller `scale`, flip `face` |
| TEXT_ON_FACE | big text over the hero | `text.pos` to `bottom`/`top`, or a wider shot |
| ACTORS_OVERLAP | two people standing in each other | 16+ points of `x` between them |
| LONG_SHOT | the picture hangs (3.6 s early, 5 s later) | split the line into two shots |
| PACE_START | fewer than 24 cuts/min in the first 30 s | split the longest early shots |
| SAME_FRAME | a cut nobody can see | change camera size, pose or place |
| STATIC | a frozen drawing | add `camera.move`, `toPose`, `toX`, `motion`, a moving prop or an fx |
| ONE_HERO | the hero disappears for too long | put the hero back in the shot |
| LOCATIONS | everything happens in one room | each situation gets its own background |
| FACT / FACT_SOURCE / FACT_FILE | no real fact, or no source | write the fact beat, `source`, and fact.md |
| ENDING | no question to the viewer | last shot `beat: "question"`, line ends with `?` |

Things only eyes catch (fix them too):
- the hero is tiny in a wide shot for three shots in a row -> use `medium`, or `scale` 1.2
- the important prop is small -> `size` 200+ for a prop that is the subject of the shot
- the reveal has no emphasis -> add `fx: ["flash"]`, a label, or `camera.move: "push"`
- night shot after night shot -> change `time` when the mood changes (sunset = warm, night = dark beat, day = fact)
- the thumbnail shot: one hero, one situation, readable at phone size
