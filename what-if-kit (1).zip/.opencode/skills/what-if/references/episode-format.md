# episode.json - every field

One file describes the whole cartoon. The engine draws it. Use ONLY the names listed here.

```json
{
  "slug": "see-one-minute-ahead",
  "title": "What If You Could See One Minute Ahead?",
  "language": "en",
  "length": "short",
  "hero": "max",
  "subtitles": "off",
  "shots": [ { ...shot... }, { ...shot... } ]
}
```

`subtitles`: `"off"` or `"words"` (burned-in word-by-word captions). `music`: optional file name
from `./music` (first file there is used automatically; `"music": false` turns it off).

## Shot

```json
{
  "beat": "small",
  "say": "You catch the ball before anyone throws it.",
  "bg": "park", "time": "day",
  "camera": {"size": "wide", "on": "max", "move": "static"},
  "actors": [
    {"who": "max", "x": 30, "pose": "catch", "mood": "smug"},
    {"who": "sam", "x": 78, "face": "left", "pose": "stand", "toPose": "throw", "switchAt": 0.55}
  ],
  "props": [{"type": "ball", "x": 73, "y": 52, "toX": 37, "toY": 49, "arc": 190, "size": 80, "spin": 2}],
  "sfx": "whoosh"
}
```

| field | meaning |
|---|---|
| `beat` (required) | hook, rules, small, bigger, dark, fact, question - in this order through the episode |
| `say` (required) | the narration spoken during this shot. The shot lasts exactly as long as these words |
| `pause` | extra seconds of silence after the words (use 0.4-0.8 on the last shot only) |
| `bg` (required) | room, bedroom, classroom, office, kitchen, shop, lab, stage, street, rooftop, park, forest, beach, space, void, mountain |
| `time` | day, sunset (default, warm), night, dawn - changes all the lighting |
| `camera` | see Camera |
| `actors` | 0-3 characters, see Actor |
| `props` | free-standing objects, see Prop |
| `crowd` | background people: `{"count": 6, "pose": "cheer", "labels": ["IQ 90", "IQ 131"]}` (max 14) |
| `text` | big on-screen words, see Text |
| `source` | fact source caption at the bottom, max 64 characters: "Nijhawan, Nature, 1994" |
| `fx` | list of: flash, darken, red, gold, speedlines, rain, snow, sparkles, confetti, hearts, freeze, glitch, fade-in, fade-out |
| `sfx` | one name or a list: whoosh, pop, ding, boing, thud, rise, drop, cash, tick, heartbeat, gasp, wow, magic, glitch, bell, click, splash, crash, laugh, record-scratch, sparkle, alarm, wind, zap |

Coordinates: `x` is 0-100 across the frame (0 left, 50 centre, 100 right). `y` for props is 0-100
down the frame, or `"ground"`. Characters stand on the ground automatically.

## Camera

| field | values |
|---|---|
| `size` | `wide` (whole scene), `medium` (waist up, default for dialogue), `close` (face), `extreme` (eyes - rare) |
| `on` | who the camera looks at: an actor's `who`, an index (0 = first actor), `"center"`, or `{"x": 50, "y": 40}`. Default: the hero. With two actors in a `medium` shot use `"center"` and keep them 25-32 points apart |
| `move` | `static`, `push` (slow zoom in - tension, reveals), `pull` (zoom out - loneliness, scale), `pan-left`, `pan-right`, `drift`, `shake` (impact) |

## Actor

| field | meaning |
|---|---|
| `who` (required) | a key from characters.json: max, mia, sam, prof, boss, granny, rival, extra, or one you added |
| `x`, `toX` | position; `toX` makes the actor travel there during the shot (use with pose `walk`/`run`; below 0 or above 100 = leaves the frame) |
| `face` | `right` (default) or `left`. Two people talking face each other |
| `scale`, `toScale` | size, 1 = normal. `toScale` grows/shrinks during the shot |
| `y` | lift in pixels, negative = up (-200 floats above the ground) |
| `pose`, `toPose`, `switchAt` | pose, the pose to change to, and when (0-1, default 0.5) |
| `mood`, `toMood` | face: neutral, happy, laugh, sad, cry, shock, scared, angry, smug, think, sleepy, wink, love, dead, determined |
| `hold`, `holdSize` | a prop in the front hand (any prop name); size in px, default 84 |
| `label` | a tag above the head. Text: `"IQ 142"`. Coloured: `{"text": "LUCKY", "color": "green"}` (dark, white, green, red, gold, blue). Counting: `{"from": 0, "to": 1000000, "prefix": "$"}`. Max 14 characters |
| `bubble` | `{"type": "thought", "icon": "clock"}` or `{"type": "speech", "text": "Pizza, right?"}` - max 42 characters |
| `motion` | jump, shake, tremble, nod, float, spin, pop |
| `ghost` | `true` = half-transparent (future self, memory, the other timeline) |
| `glow` | coloured aura, e.g. `"rgba(255,220,90,.9)"` for a power-up |

Poses: stand, relaxed, point, point-up, point-back, wave, think, shrug, cheer, facepalm, hold, hold-up, hold-out, carry, reach, catch, throw, phone, read, type, sit, sit-ground, kneel, crouch, walk, run, sneak, jump, fly, float, fall, lie, sleep, scared, cover-eyes, hands-hips, cross, strong, punch, kick, push, pull, sad, look-up, bow, dance, dizzy, proud, listen, count, drive, eat

Poses that animate by themselves: walk, run, sneak, wave, dance, type, cheer.

## Prop

`{"type": "car", "x": 118, "toX": 52, "y": 78, "size": 520}`

| field | meaning |
|---|---|
| `type` (required) | ball, phone, book, coin, cash, clock, hourglass, laptop, cup, box, gift, bulb, key, umbrella, heart, star, trophy, apple, paper, bag, lightning, fire, question, exclaim, zzz, brain, snail, car, rocket, bed, desk, chair, door, tree, bench, tv, sign, mirror, safe, calendar, pizza, dumbbell, crown, planet, cloud, arrow, ticket, mask |
| `x`, `y` (x required) | position of the centre; `y` 0-100 or `"ground"` (default) |
| `toX`, `toY`, `arc` | where it flies to during the shot; `arc` = height of the throw in px |
| `size`, `toSize` | width in px (default 120); `toSize` grows/shrinks |
| `rot`, `spin` | rotation in degrees; `spin` = full turns during the shot |
| `layer` | `front` (default, over the characters) or `back` |
| `text` | writing on: sign, paper, tv, calendar, ticket (short!) |
| `cover` | `true` if it is MEANT to cover a face (mask) |

## Text

`{"value": "A guess.", "style": "impact", "pos": "top"}`

| field | meaning |
|---|---|
| `value` | 1-5 words. The voice tells the story; text only punches one idea |
| `style` | `title` (max 60 chars), `impact` (huge, yellow, capitals, max 32), `note` (small, max 104) |
| `pos` | `top` (default), `center`, `bottom` |
| `color` | hex colour |
| `count` | a running number instead of `value`: `{"from": 0, "to": 60, "suffix": " sec"}` or `{"from": 60, "to": 0, "prefix": "0:"}` |

## Staging recipes

- **"See everyone's X"** (IQ, wealth, days left): `crowd` with `labels`, hero in front with his own `label`; then `close` on one person with a shocking label.
- **Reveal**: `close` + `move: "push"` + `toMood: "shock"` + `fx: ["flash"]` + `sfx: "ding"`.
- **Something flies**: a prop with `toX`/`toY`/`arc`, the catcher in pose `catch`, the other in `throw`.
- **Chase / hurry**: pose `run` with `toX`, `fx: ["speedlines"]`, `camera.move: "shake"` on the impact.
- **Money**: `hold: "cash"`, a `label` counting up, `fx: ["confetti"]`, `sfx: "cash"`.
- **Time**: prop `clock` or `hourglass`, `text.count` running, `sfx: "tick"`.
- **Loneliness**: `wide`, `move: "pull"`, pose `sit-ground`, `time: "night"`.
- **Two timelines / future self**: the same `who` twice, one with `"ghost": true`.
- **The fact**: `bg: "lab"` or `void`, `prof` pointing, one big prop (brain, planet, clock), `source` on the key shot.
- **The ending**: `close` on the hero pointing at the camera, mood `wink`, the question as `text` at the `bottom`.
