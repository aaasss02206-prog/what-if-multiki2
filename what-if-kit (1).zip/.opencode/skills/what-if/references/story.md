# Story: how to write the narration

The narration is ONE voice talking to "you". Present tense. Short lines. No names for the hero.

## Beats (in this order - the checker enforces it)

| beat | share of shots | what happens | example line |
|---|---|---|---|
| `hook` | 1-2 | the question, word for word | "What if you could see one minute into the future?" |
| `rules` | 1-3 | the limit that makes it a game | "Not years. Not days. Just the next sixty seconds." |
| `small` | 15-20% | tiny everyday wins, funny | "You catch the ball before anyone throws it." |
| `bigger` | 25-30% | money, status, other people notice | "People start calling you lucky. Then gifted. Then dangerous." |
| `dark` | 15-20% | the price - what you lose | "Every surprise is gone." |
| `fact` | 15-20% | the real science, with a source on screen | "Your brain already does this." |
| `question` | 2-3 | hand it to the viewer | "Would you look?" |

## Line rules

- One line = one shot = one picture. 4-9 words. First 30 seconds: max 50 characters per line.
  After that: max 70. A longer sentence is split across two shots at a natural pause.
- Concrete, visible things only. Not "you become successful" but "you buy the ticket you watched win".
  If you cannot draw it with one hero and one prop, rewrite it.
- Rule of three for escalation: "lucky. Then gifted. Then dangerous." = three quick shots.
- No filler: no "imagine", "in this video", "let's find out", "but wait", "little did you know".
- No lists of adjectives. No rhetorical questions except the hook and the final one.
- Numbers make it real: "sixty seconds", "a tenth of a second", "$4 million".
- The dark beat is about loss and irony, not horror. Keep it something a 14-year-old and a
  40-year-old can both watch.
- Total for a short episode: 950-1500 characters of narration.

## Escalation ladder (pick 5-7 situations, each in its own place)

small: school / friends / games / food / being late
bigger: money / work / love / fame / being noticed by powerful people
dark: boredom of knowing / people fear you / you cannot switch it off / one thing you cannot change

## Fact

The fact answers "is any of this real?". Good facts are surprising, simple, and safely true:
- how the brain or body already does a tiny version of the superpower
- a measured limit (reaction time, memory span, sleep need, how far a human can grow)
- a real experiment with a clear result
- a number from physics or biology that makes the fantasy collapse or come true

Say it in 3-6 short lines: setup ("Here's the strange part."), the fact in plain words, what it
means for the what-if. Put `"source": "Author or institution, journal, year"` on the shot where
the fact is stated (max 64 characters). Use careful verbs when the science is one explanation
among several: "suggests", "one explanation is". Never use: "scientists proved", "studies show"
without the study, medical advice, statistics you cannot source.

## Ending

Last 2-3 shots: connect the fact back to the viewer, then ask. The final line is a direct question
with "you" in it, 2-6 words, and the same words appear on screen:
"Would you look?" / "Would you still press it?" / "What would you do with the first hour?"
