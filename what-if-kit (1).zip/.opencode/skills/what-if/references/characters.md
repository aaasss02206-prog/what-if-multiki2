# Characters

Every character is drawn by the same code. A character is only a wardrobe entry in
`characters.json` in the project folder - that is why a hero looks identical in every shot of
every episode. To add a hero, add an entry; never try to draw one.

```json
"zoe": {
  "name": "Zoe",
  "hair": "ponytail", "hairColor": "#5a3825",
  "top": "raincoat", "topColor": "#ffd60a",
  "bottom": "pants", "bottomColor": "#3d405b",
  "shoes": "boots", "shoesColor": "#e63946",
  "accessory": "none"
}
```

| field | values |
|---|---|
| `hair` | none, short, spiky, ponytail, bob, long, bun, curly, cap, beanie, tophat |
| `top` | none, tshirt, hoodie, sweater, raincoat, suit, labcoat, dress, tank, jacket |
| `bottom` | none, pants, shorts, skirt |
| `shoes` | none, sneakers, boots |
| `accessory` | none, glasses, sunglasses, scarf, backpack, headphones, crown, tie, bow, cape |
| colours | any hex colour: `hairColor`, `topColor`, `bottomColor`, `shoesColor`, `accessoryColor` |
| `line`, `skin` | body line colour and head fill (defaults: near-black and white) |

The key (`"zoe"`) is what you write in `"who"`. Lowercase, no spaces.
Built-in cast: max (default hero), mia, sam, prof, boss, granny, rival, extra.
Give a new hero ONE loud colour that nobody else in the cast wears - it is how viewers find them
in a wide shot and on a thumbnail.

After any change:

    whatif sheet

and show `character-sheet.png` to the user.
